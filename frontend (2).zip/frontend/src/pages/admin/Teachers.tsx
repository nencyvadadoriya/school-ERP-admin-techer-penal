import React, { useState, useEffect } from 'react';
import { teacherAPI, classAPI, subjectAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { FaPlus, FaEdit, FaTrash, FaSearch, FaEye, FaHistory } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const Teachers: React.FC = () => {
  const navigate = useNavigate();
  const [teachers, setTeachers] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showForm, setShowForm] = useState<boolean>(false);
  const [selectedTeacher, setSelectedTeacher] = useState<any | null>(null);
  const [availableSubjects, setAvailableSubjects] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    password: '',
    experience: '',
    subjects: [],
    medium: '',
    assigned_class: '',
    about: '',
  });

  const buildClassCode = (cls: any) => {
    const standard = cls?.standard ?? '';
    const division = cls?.division ?? '';
    const medium = cls?.medium ?? '';
    const stream = cls?.stream ?? '';
    const shift = cls?.shift ?? '';
    return `STD-${standard}-${division}-${medium}-${stream || 'NA'}-${shift || 'NA'}`;
  };

  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [activeMobileTab, setActiveMobileTab] = useState<string>('list');

  const theme = {
    primary: '#002B5B',
    secondary: '#2D54A8',
    accent: '#FFC107',
    background: '#F0F2F5',
    white: '#FFFFFF',
    textPrimary: '#1F2937',
    textSecondary: '#6B7280',
    success: '#10B981',
    danger: '#EF4444'
  };

 

  useEffect(() => {
    fetchTeachers();
    fetchClasses();
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const checkMobile = () => {
    setIsMobile(window.innerWidth < 768);
  };

  // Jab assigned_class change ho, toh us class ke subjects fetch karo
  useEffect(() => {
    if (formData.assigned_class) {
      fetchSubjectsForClass(formData.assigned_class);
      // Reset subjects when class changes
      setFormData(prev => ({ ...prev, subjects: [] }));
    } else {
      setAvailableSubjects([]);
      setFormData(prev => ({ ...prev, subjects: [] }));
    }
  }, [formData.assigned_class]);

  const fetchTeachers = async () => {
    try {
      const res = await teacherAPI.getAll();
      setTeachers(res.data.data || []);
    } catch (err) {
      toast.error('Error fetching teachers');
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async () => {
    try {
      const res = await classAPI.getAll();
      setClasses(res.data.data || []);
    } catch (err) {
      console.error('Error fetching classes:', err);
      toast.error('Error fetching classes');
    }
  };

  // Class ke subjects fetch karne ka function
  const fetchSubjectsForClass = async (className) => {
    try {
      const selectedClass = classes.find((c) => buildClassCode(c) === className);

      if (!selectedClass) {
        setAvailableSubjects([]);
        return;
      }

      const params: any = {
        std: String(selectedClass.standard),
        medium: selectedClass.medium,
      };
      if (selectedClass.stream) params.stream = selectedClass.stream;

      const res = await subjectAPI.getAll(params);
      const list = res?.data?.data || [];
      const names = list.map((s: any) => s.subject_name).filter(Boolean);

      if (names.length > 0) {
        setAvailableSubjects(names);
      } else {
        setAvailableSubjects([]);
        toast.info('No subjects found for this class. Please add subjects to the class first.');
      }
    } catch (err) {
      console.error('Error fetching subjects:', err);
      setAvailableSubjects([]);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this teacher?')) return;
    try {
      await teacherAPI.delete(id);
      toast.success('Teacher deleted');
      fetchTeachers();
    } catch (err) {
      toast.error('Error deleting teacher');
    }
  };

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    if (name === 'medium') {
      setFormData((s) => ({
        ...s,
        medium: value,
        assigned_class: '',
        subjects: [],
      }));
      setAvailableSubjects([]);
      return;
    }

    setFormData((s) => ({ ...s, [name]: value }));
  };

  const handleClassChange = (e: any) => {
    const value = e.target.value;
    const selectedClass = classes.find((c) => buildClassCode(c) === value);
    setFormData((s) => ({
      ...s,
      assigned_class: value,
      subjects: [],
      medium: selectedClass?.medium || s.medium,
    }));
  };

  const handleSubjectsChange = (e: any) => {
    const selectedOptions = Array.from((e.target as HTMLSelectElement).selectedOptions, (option: any) => option.value);
    setFormData((s) => ({ ...s, subjects: selectedOptions }));
  };

  const openAddForm = () => {
    setSelectedTeacher(null);
    setFormData({
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      password: '',
      experience: '',
      subjects: [],
      medium: '',
      assigned_class: '',
      about: '',
    });
    setAvailableSubjects([]);
    setShowForm(true);
  };

  const openEditForm = (t) => {
    setSelectedTeacher(t);
    const assignedClassValue = Array.isArray(t.assigned_class)
      ? (t.assigned_class[0] || '')
      : (t.assigned_class || '');
    const selectedClass = assignedClassValue
      ? classes.find((c) => buildClassCode(c) === assignedClassValue)
      : null;
    setFormData({
      first_name: t.first_name || '',
      last_name: t.last_name || '',
      email: t.email || '',
      phone: t.phone || '',
      password: '',
      experience: t.experience || '',
      subjects: t.subjects || [],
      medium: t.medium || selectedClass?.medium || '',
      assigned_class: assignedClassValue,
      about: t.about || '',
    });
    
    // Edit mode me bhi subjects fetch karo agar class assigned hai
    if (assignedClassValue) {
      fetchSubjectsForClass(assignedClassValue);
    }
    setShowForm(true);
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        subjects: formData.subjects,
        assigned_class: formData.assigned_class,
        experience: formData.experience ? Number(formData.experience) : 0,
      };
      
      if (selectedTeacher) {
        await teacherAPI.update(selectedTeacher._id || selectedTeacher.id, payload);
        toast.success('Teacher updated');
      } else {
        const res = await teacherAPI.register(payload);
        if (res?.data?.generated_password) {
          toast.success(`Teacher added. Password: ${res.data.generated_password}`);
        } else {
          toast.success('Teacher added');
        }
      }
      setShowForm(false);
      setSelectedTeacher(null);
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        password: '',
        experience: '',
        subjects: [],
        medium: '',
        assigned_class: '',
        about: '',
      });
      setAvailableSubjects([]);
      fetchTeachers();
    } catch (err) {
      const data = err.response?.data;
      if (data?.message === 'Validation error' && data.errors) {
        const msgs = Object.keys(data.errors).map((k) => `${k}: ${data.errors[k]}`);
        toast.error(msgs.join(' | '));
      } else if (data?.message) {
        toast.error(data.message);
      } else {
        toast.error('Error saving teacher');
      }
    }
  };

  const filtered = teachers.filter(t =>
    t.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (t.email || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const classOptions = formData.medium
    ? classes.filter((c) => c?.medium === formData.medium)
    : classes;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderBottomColor: theme.primary }}></div>
      </div>
    );
  }

  if (isMobile) {
    const renderMobileContent = () => {
      switch (activeMobileTab) {
        case 'add':
          return (
            <div className="p-2 space-y-4">
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center">
                <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <FaPlus size={32} style={{ color: theme.primary }} />
                </div>
                <h2 className="text-xl font-black mb-2" style={{ color: theme.primary }}>Add New Teacher</h2>
                <p className="text-sm text-gray-500 mb-6">Create a new teacher account and assign classes</p>
                <button 
                  onClick={openAddForm}
                  className="w-full py-4 rounded-2xl text-white font-bold shadow-lg transition-all active:scale-95 hover:brightness-110"
                  style={{ backgroundColor: theme.primary }}
                >
                  Configure New Teacher
                </button>
              </div>
            </div>
          );
        case 'list':
        default:
          return (
            <div className="p-2 space-y-3">
              <div className="rounded-xl p-4 text-white overflow-hidden relative shadow-md"
                style={{ background: `linear-gradient(135deg, ${theme.primary}, ${theme.secondary})` }}>
                <div className="relative z-10">
                  <p className="text-[8px] opacity-80 uppercase tracking-widest font-bold">Admin Panel</p>
                  <h2 className="text-lg font-extrabold mt-0.5">Teachers</h2>
                  <div className="flex items-center mt-2 text-[9px] opacity-70">
                    <FaPlus size={10} className="mr-1.5" />
                    <span>{teachers.length} Active Staff</span>
                  </div>
                </div>
                <div className="absolute right-[-10px] top-[-10px] opacity-10">
                  <FaPlus size={80} />
                </div>
              </div>

              <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-100">
                <div className="relative group">
                  <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xs" />
                  <input
                    type="text"
                    placeholder="Search teachers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-100 rounded-lg text-[10px] focus:outline-none focus:ring-1 transition-all"
                    style={{ '--tw-ring-color': `${theme.primary}20` } as any}
                  />
                </div>
              </div>

              <div className="space-y-2 pb-20">
                {filtered.map((t) => (
                  <div key={t._id} className="bg-white p-3 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="h-10 w-10 rounded-lg bg-blue-50 flex items-center justify-center font-bold text-primary-600 text-sm"
                          style={{ backgroundColor: `${theme.primary}10`, color: theme.primary }}>
                          {(t.first_name?.charAt(0) || '') + (t.last_name?.charAt(0) || '')}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-gray-900 leading-tight">{t.first_name} {t.last_name}</h4>
                          <p className="text-[9px] text-gray-400 font-medium mt-0.5">{t.email}</p>
                        </div>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded-md text-[8px] font-bold uppercase tracking-wider ${t.is_active ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                        {t.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mb-2">
                      <div className="bg-gray-50 p-1.5 rounded-lg text-center">
                        <p className="text-[7px] text-gray-400 font-bold uppercase">Class</p>
                        <p className="text-[9px] font-bold text-gray-700 truncate">{t.assigned_class || 'None'}</p>
                      </div>
                      <div className="bg-gray-50 p-1.5 rounded-lg text-center">
                        <p className="text-[7px] text-gray-400 font-bold uppercase">Exp.</p>
                        <p className="text-[9px] font-bold text-gray-700">{t.experience} Yrs</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                       <button onClick={() => navigate(`/admin/teacher-history/${t._id}`)} className="flex-1 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-bold flex items-center justify-center gap-1.5">
                        <FaHistory size={10}/> History
                      </button>
                      <button onClick={() => openEditForm(t)} className="flex-1 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-[9px] font-bold flex items-center justify-center gap-1.5">
                        <FaEdit size={10}/> Edit
                      </button>
                      <button onClick={() => handleDelete(t._id)} className="p-1.5 bg-red-50 text-red-600 rounded-lg">
                        <FaTrash size={10}/>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
      }
    };

    return (
      <div className="min-h-screen bg-[#F0F2F5]">
        <div className="pb-20 p-0">
          {renderMobileContent()}
        </div>
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 border-t border-gray-200 backdrop-blur-xl">
          <div className="flex items-center justify-around py-3 px-2">
            {[
              { id: 'list', Icon: FaPlus, label: 'Wait' }, // Using FaPlus icon with 'Teachers' text
              { id: 'list', Icon: FaSearch, label: 'Teachers' },
              { id: 'add', Icon: FaPlus, label: 'Add' },
            ].map(({ id, Icon, label }, idx) => (
              idx !== 0 && (
                <button key={idx} onClick={() => setActiveMobileTab(id)} className="flex flex-col items-center flex-1 py-1">
                  <Icon size={20} className={activeMobileTab === id ? 'text-[#002B5B]' : 'text-gray-400'} />
                  <span className={`text-[10px] mt-1 ${activeMobileTab === id ? 'text-[#002B5B] font-bold' : 'text-gray-500'}`}>{label}</span>
                </button>
              )
            ))}
          </div>
        </div>

        {showForm && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-2 sm:p-4">
            <div className="bg-white rounded-2xl w-[95%] sm:w-full max-w-lg p-4 sm:p-6 shadow-2xl overflow-y-auto max-h-[90vh] border border-gray-100">
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <h2 className="text-lg sm:text-xl font-bold" style={{ color: theme.primary }}>
                  {selectedTeacher ? 'Edit Teacher' : 'Add Teacher'}
                </h2>
                <button onClick={() => setShowForm(false)} className="h-8 w-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-gray-100 transition-colors text-xl">
                  &times;
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">First Name</label>
                    <input name="first_name" value={formData.first_name} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">Last Name</label>
                    <input name="last_name" value={formData.last_name} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-500 ml-1">Email</label>
                  <input name="email" type="email" value={formData.email} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">Phone</label>
                    <input name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">Experience (Yrs)</label>
                    <input name="experience" type="number" value={formData.experience} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                </div>
                {!selectedTeacher && (
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">Password</label>
                    <input name="password" type="password" value={formData.password} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                )}
                 <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 ml-1">Assigned Class</label>
                    <select value={formData.assigned_class} onChange={handleClassChange} name="assigned_class" className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" required>
                      <option value="">Select class</option>
                      {classOptions.map((cls) => (
                        <option key={cls._id} value={buildClassCode(cls)}>{cls.standard}{cls.division} - {cls.medium}</option>
                      ))}
                    </select>
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-3 rounded-xl text-sm font-bold text-gray-500 border border-gray-200">Cancel</button>
                  <button type="submit" className="flex-1 py-3 rounded-xl text-sm font-bold text-white" style={{ backgroundColor: theme.primary }}>Save</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3 sm:space-y-4 p-3 sm:p-4 min-h-screen" style={{ backgroundColor: theme.background }}>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-3 rounded-xl shadow-sm border border-gray-100">
        <div>
          <h1 className="text-lg sm:text-xl font-black tracking-tight" style={{ color: theme.primary }}>Teachers Management</h1>
          <p className="text-[10px] sm:text-xs font-medium text-gray-500">Manage all staff and teaching assignments</p>
        </div>
        <button 
          onClick={openAddForm} 
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-white text-xs font-bold shadow-md transition-all active:scale-95 hover:brightness-110"
          style={{ backgroundColor: theme.primary }}
        >
          <FaPlus size={12} />
          <span>Add Teacher</span>
        </button>
      </div>

      <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100">
        <div className="relative group max-w-md">
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xs" />
          <input
            type="text"
            placeholder="Search teachers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-100 rounded-lg text-xs focus:outline-none focus:ring-1 transition-all"
            style={{ '--tw-ring-color': `${theme.primary}40` } as any}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-100">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">#</th>
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">Name</th>
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">Contact</th>
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">Experience</th>
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">Class</th>
                <th className="px-4 py-3 text-left text-[9px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                <th className="px-4 py-3 text-right text-[9px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((t, index) => (
                <tr key={t._id} className="hover:bg-gray-50/50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-medium text-gray-400">{index + 1}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg flex items-center justify-center font-bold text-[10px]"
                        style={{ backgroundColor: `${theme.primary}10`, color: theme.primary }}>
                        {(t.first_name?.charAt(0) || '') + (t.last_name?.charAt(0) || '')}
                      </div>
                      <span className="text-xs font-bold text-gray-900">{t.first_name} {t.last_name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{t.email}<br/><span className="text-[9px] text-gray-400">{t.phone}</span></td>
                  <td className="px-4 py-3 text-xs font-bold text-gray-700">{t.experience} Yrs</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-600">{t.assigned_class || 'None'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider ${t.is_active ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                      {t.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1.5">
                       <button onClick={() => navigate(`/admin/teacher-history/${t._id}`)} className="p-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-all"><FaHistory size={12} /></button>
                      <button onClick={() => openEditForm(t)} className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-all"><FaEdit size={12} /></button>
                      <button onClick={() => handleDelete(t._id)} className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-all"><FaTrash size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" style={{ color: theme.primary }}>{selectedTeacher ? 'Edit Teacher' : 'Add Teacher'}</h2>
              <button onClick={() => setShowForm(false)} className="text-2xl text-gray-400 hover:text-gray-600">&times;</button>
            </div>
            <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">First Name</label>
                <input name="first_name" value={formData.first_name} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Last Name</label>
                <input name="last_name" value={formData.last_name} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Email</label>
                <input name="email" type="email" value={formData.email} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Phone</label>
                <input name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
              </div>
              {!selectedTeacher && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Password</label>
                  <input name="password" type="password" value={formData.password} onChange={handleChange} required className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
                </div>
              )}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Experience (Years)</label>
                <input name="experience" type="number" value={formData.experience} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} />
              </div>
              <div className="col-span-2 space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Assigned Class</label>
                <select value={formData.assigned_class} onChange={handleClassChange} name="assigned_class" className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2" style={{ '--tw-ring-color': `${theme.primary}20` } as any} required>
                  <option value="">Select class</option>
                  {classOptions.map((cls) => (
                    <option key={cls._id} value={buildClassCode(cls)}>{cls.standard}{cls.division} - {cls.medium}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 flex justify-end gap-3 mt-4">
                <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2 rounded-xl text-sm font-bold text-gray-500 hover:bg-gray-50 border border-gray-200 transition-colors">Cancel</button>
                <button type="submit" className="px-8 py-2 rounded-xl text-sm font-bold text-white shadow-lg transition-all active:scale-95" style={{ backgroundColor: theme.primary }}>Save Teacher</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Teachers;