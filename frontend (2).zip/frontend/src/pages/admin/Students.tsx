import React, { useState, useEffect } from 'react';
import { studentAPI, classAPI } from '../../services/api';
import { toast } from 'react-toastify';
import {
  FaPlus, FaEdit, FaTrash, FaHistory, FaCheck, FaTimes,
  FaTable, FaChevronDown, FaEye, FaEyeSlash
} from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const themeConfig = {
  primary: '#002B5B',
  secondary: '#2D54A8',
  accent: '#FFC107',
  success: '#10B981',
  warning: '#f59e0b',
  danger: '#EF4444',
  info: '#3b82f6',
  background: '#F0F2F5',
  white: '#FFFFFF',
  textPrimary: '#1F2937',
  textSecondary: '#6B7280',
  dark: '#1f2937',
  light: '#f9fafb',
};

const StudentStyleSheet = () => (
  <style>{`
    .student-container { background: ${themeConfig.background}; min-height: 100vh; }
    .btn-base { padding: 0.625rem 1.25rem; border: none; border-radius: 0.625rem; font-weight: 600; font-size: 0.8125rem; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem; transition: all 0.2s; }
    .btn-primary { background: linear-gradient(135deg, ${themeConfig.primary} 0%, ${themeConfig.secondary} 100%); color: white; }
    .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
    .btn-secondary { background: rgba(0,43,91,0.08); color: ${themeConfig.primary}; border: 1.5px solid ${themeConfig.primary}; }
    .btn-secondary:hover { background: rgba(0,43,91,0.15); }
    .btn-danger { background: rgba(239,68,68,0.08); color: ${themeConfig.danger}; border: 1.5px solid ${themeConfig.danger}; }
    .btn-danger:hover { background: ${themeConfig.danger}; color: white; }
    .input-field { width: 100%; padding: 0.5rem 0.875rem; border: 1.5px solid #e5e7eb; border-radius: 0.625rem; font-size: 0.875rem; transition: all 0.2s; background: white; box-sizing: border-box; }
    .input-field:focus { outline: none; border-color: ${themeConfig.primary}; box-shadow: 0 0 0 3px rgba(0,43,91,0.08); }
    .select-wrapper { position: relative; }
    .select-wrapper select { appearance: none; padding-right: 2rem; }
    .select-wrapper::after { content: ''; position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%); pointer-events: none; width: 14px; height: 14px; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23002B5B'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E"); background-size: contain; background-repeat: no-repeat; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.45); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 1rem; animation: fadeIn 0.2s ease-out; }
    .modal-content { background: white; border-radius: 1rem; max-width: 48rem; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); animation: slideUp 0.25s cubic-bezier(0.4,0,0.2,1); }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slideUp { from { transform: translateY(1rem); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .spinner { animation: spin 1s linear infinite; border-top-color: ${themeConfig.primary}; }
    @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    @media (max-width: 640px) {
      .modal-content { max-width: 100%; border-radius: 1.25rem 1.25rem 0 0; max-height: 95vh; margin-top: auto; }
      .modal-overlay { align-items: flex-end; padding: 0; }
    }
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,43,91,0.25); border-radius: 10px; }
  `}</style>
);

const Students: React.FC = () => {
  const navigate = useNavigate();
  const [students, setStudents] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('');
  const [selectedStdFilter, setSelectedStdFilter] = useState<string>('');
  const [selectedShiftFilter, setSelectedShiftFilter] = useState<string>('');
  const [selectedMediumFilter, setSelectedMediumFilter] = useState<string>('');
  const [selectedStudents, setSelectedStudents] = useState<Set<string>>(new Set());
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showBulkModal, setShowBulkModal] = useState<boolean>(false);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);
  const [bulkRows, setBulkRows] = useState<any[]>([]);
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [bulkApplyAll, setBulkApplyAll] = useState({
    std: '', shift: '', gender: '', stream: '', medium: '',
    fees: '', class_name: '', pin: '', password: '',
  });
  const [bulkSubmitting, setBulkSubmitting] = useState<boolean>(false);
  const [bulkResults, setBulkResults] = useState<any | null>(null);
  const [bulkInputText, setBulkInputText] = useState<string>('');

  const [formData, setFormData] = useState({
    std: '', roll_no: '', first_name: '', middle_name: '', last_name: '',
    gender: '', phone1: '', phone2: '', address: '', pin: '',
    class_code: '', class_name: '', password: '', fees: '',
    shift: '', stream: '', medium: '',
  });

  const getStreamOptions = (std: string) => {
    const n = Number(std);
    if (n >= 11) return [{ value: 'Science-Maths', label: 'Science-Maths' }, { value: 'Science-Bio', label: 'Science-Bio' }, { value: 'Commerce', label: 'Commerce' }, { value: 'Higher Secondary', label: 'Higher Secondary' }];
    if (n >= 9) return [{ value: 'Foundation', label: 'Foundation' }, { value: 'Secondary', label: 'Secondary' }];
    if (n >= 6) return [{ value: 'Upper Primary', label: 'Upper Primary' }];
    if (n >= 1) return [{ value: 'Primary', label: 'Primary' }];
    return [];
  };

  const parseBulkInput = (text: string) => {
    const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
    return lines.map(line => {
      if (line.includes('|') && line.includes(':')) {
        const student: any = {
          first_name: '', last_name: '', middle_name: '', phone1: '', phone2: '', address: '',
          std: bulkApplyAll.std, class_name: bulkApplyAll.class_name, shift: bulkApplyAll.shift,
          gender: bulkApplyAll.gender, stream: bulkApplyAll.stream, medium: bulkApplyAll.medium,
          fees: bulkApplyAll.fees, pin: bulkApplyAll.pin, password: bulkApplyAll.password,
        };
        line.split('|').forEach(part => {
          const [key, ...valParts] = part.split(':');
          const value = valParts.join(':').trim();
          const k = key.trim().toLowerCase().replace(/\s/g, '');
          if (k === 'firstname') student.first_name = value;
          else if (k === 'lastname') student.last_name = value;
          else if (k === 'middlename') student.middle_name = value;
          else if (k === 'phone1') student.phone1 = value;
          else if (k === 'phone2') student.phone2 = value;
          else if (k === 'address') student.address = value;
        });
        student.first_name = student.first_name.replace(/^\d+[\.\s]*/, '').trim();
        return student;
      }
      const columns = line.split(line.includes('\t') ? '\t' : ',');
      return {
        first_name: (columns[0] || '').replace(/^\d+[\.\s]*/, '').trim(),
        last_name: columns[1]?.trim() || '', phone1: columns[2]?.trim() || '',
        phone2: columns[3]?.trim() || '', address: columns[4]?.trim() || '',
        std: columns[5]?.trim() || bulkApplyAll.std, class_name: columns[6]?.trim() || bulkApplyAll.class_name,
        pin: columns[7]?.trim() || bulkApplyAll.pin, password: columns[8]?.trim() || bulkApplyAll.password,
        shift: bulkApplyAll.shift, gender: bulkApplyAll.gender, stream: bulkApplyAll.stream,
        fees: bulkApplyAll.fees, middle_name: '',
      };
    });
  };

  const handleAddToList = () => {
    if (!bulkInputText.trim()) { toast.error('Please paste some data first'); return; }
    const parsed = parseBulkInput(bulkInputText);
    setBulkRows(prev => (prev.length === 1 && !prev[0].first_name && !prev[0].last_name) ? parsed : [...prev, ...parsed]);
    setBulkInputText('');
    toast.success(`Added ${parsed.length} students to the list`);
  };

  const handleBulkRowChange = (index: number, field: string, value: any) => {
    const updated = [...bulkRows];
    updated[index] = { ...updated[index], [field]: value };
    setBulkRows(updated);
  };

  const addBulkRow = () => {
    setBulkRows([...bulkRows, {
      first_name: '', middle_name: '', last_name: '', phone1: '', phone2: '', address: '',
      pin: bulkApplyAll.pin, password: bulkApplyAll.password, std: bulkApplyAll.std,
      class_name: bulkApplyAll.class_name, shift: bulkApplyAll.shift, gender: bulkApplyAll.gender,
      stream: bulkApplyAll.stream, medium: bulkApplyAll.medium, fees: bulkApplyAll.fees,
    }]);
  };

  const removeBulkRow = (index: number) => setBulkRows(bulkRows.filter((_, i) => i !== index));

  const handlePaste = (e: React.ClipboardEvent) => {
    const pasteData = e.clipboardData.getData('text');
    if (!pasteData) return;
    const lines = pasteData.split(/\r?\n/).filter(l => l.trim() !== '');
    if (!lines.length) return;
    const newRows = lines.map(line => {
      const columns = line.split(line.includes('\t') ? '\t' : ',');
      return {
        first_name: columns[0] || '', last_name: columns[1] || '', phone1: columns[2] || '',
        phone2: columns[3] || '', address: columns[4] || '',
        std: columns[5] || bulkApplyAll.std, class_name: columns[6] || bulkApplyAll.class_name,
        pin: columns[7] || bulkApplyAll.pin, password: columns[8] || bulkApplyAll.password,
        shift: bulkApplyAll.shift, gender: bulkApplyAll.gender, stream: bulkApplyAll.stream,
        medium: bulkApplyAll.medium, fees: bulkApplyAll.fees, middle_name: '',
      };
    });
    setBulkRows(prev => (prev.length === 1 && !prev[0].first_name && !prev[0].last_name) ? newRows : [...prev, ...newRows]);
    toast.success(`Pasted ${newRows.length} rows from clipboard`);
  };

  useEffect(() => { fetchStudents(); fetchClasses(); }, []);

  useEffect(() => {
    const mql = window.matchMedia('(max-width: 768px)');
    const apply = () => { const m = mql.matches; setIsMobile(m); if (m) setViewMode('card'); };
    apply();
    if (mql.addEventListener) { mql.addEventListener('change', apply); return () => mql.removeEventListener('change', apply); }
  }, []);

  const fetchStudents = async () => {
    try { const r = await studentAPI.getAll(); setStudents(r.data.data); setLoading(false); }
    catch { toast.error('Error fetching students'); setLoading(false); }
  };

  const fetchClasses = async () => {
    try { const r = await classAPI.getAll(); setClasses(r.data?.data || []); }
    catch (e) { console.error('Error fetching classes:', e); }
  };

  const getUniqueClasses = () => [...new Set(students.map(s => s.class_name).filter(Boolean))].sort() as string[];
  const getUniqueStandards = () => [...new Set(students.map(s => s.std).filter(Boolean))].sort((a, b) => Number(a) - Number(b)) as string[];
  const getUniqueShifts = () => [...new Set(students.map(s => s.shift).filter(Boolean))].sort() as string[];
  const getUniqueMediums = () => [...new Set(students.map(s => s.medium).filter(Boolean))].sort() as string[];

  const filteredStudents = students
    .filter(s => {
      if (selectedClassFilter && s.class_name !== selectedClassFilter) return false;
      if (selectedStdFilter && s.std !== selectedStdFilter) return false;
      if (selectedShiftFilter && s.shift !== selectedShiftFilter) return false;
      if (selectedMediumFilter && s.medium !== selectedMediumFilter) return false;
      if (searchTerm && !s.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !s.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !s.gr_number?.toLowerCase().includes(searchTerm.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => (Number(a.roll_no) || 0) - (Number(b.roll_no) || 0));

  const handleFormChange = async (e: any) => {
    const { name, value } = e.target;
    const updated = { ...formData, [name]: value };
    if (name === 'std') updated.stream = '';
    setFormData(updated);
    if ((name === 'std' || name === 'class_name') && !selectedStudent) {
      const std = name === 'std' ? value : formData.std;
      const class_name = name === 'class_name' ? value : formData.class_name;
      if (std && class_name) {
        try {
          const res = await studentAPI.getNextRollNumber({ std, class_name, shift: formData.shift, medium: formData.medium, stream: updated.stream });
          if (res.data?.success) setFormData(prev => ({ ...prev, roll_no: res.data.nextRollNo, std, class_name }));
        } catch (e) { console.error('Error fetching next roll number:', e); }
      }
    }
  };

  const openAddModal = () => {
    setSelectedStudent(null);
    setFormData({ std: '', roll_no: '', first_name: '', middle_name: '', last_name: '', gender: '', phone1: '', phone2: '', address: '', pin: '1234', class_code: '', class_name: '', password: '123456', fees: '', shift: '', stream: '', medium: '' });
    setShowModal(true);
  };

  const openBulkModal = () => {
    setBulkResults(null); setBulkSubmitting(false); setBulkRows([]); setBulkInputText('');
    setBulkApplyAll({ std: '', class_name: '', shift: '', gender: '', stream: '', medium: '', fees: '', pin: '1234', password: '123456' });
    setShowBulkModal(true);
  };

  const handleBulkSubmit = async () => {
    const missingFields: string[] = [];
    bulkRows.forEach((row, i) => {
      if (!row.first_name || !row.last_name || !row.std || !row.class_name || !row.medium)
        missingFields.push(`Row ${i + 1}`);
    });
    if (missingFields.length) { toast.error('Missing required fields in some rows'); return; }
    const validRows = bulkRows.filter(r => r.first_name && r.last_name && r.std && r.class_name && r.medium);
    if (!validRows.length) { toast.error('Please fill at least one row'); return; }
    try {
      setBulkSubmitting(true); setBulkResults(null);
      const res = await studentAPI.bulkCreate({ students: validRows });
      setBulkResults(res?.data);
      toast.success(`Created ${res?.data?.count || 0} students`);
      setShowBulkModal(false); fetchStudents();
    } catch (err: any) {
      const msg = err?.response?.data?.message || 'Bulk create failed';
      toast.error(msg); setBulkResults(err?.response?.data || null);
    } finally { setBulkSubmitting(false); }
  };

  const openEditModal = (student: any) => {
    setSelectedStudent(student);
    setFormData({ std: student.std || '', roll_no: student.roll_no || '', first_name: student.first_name || '', middle_name: student.middle_name || '', last_name: student.last_name || '', gender: student.gender || '', phone1: student.phone1 || '', phone2: student.phone2 || '', address: student.address || '', pin: student.pin || '', class_code: student.class_code || '', class_name: student.class_name || '', password: '', fees: student.fees || '', shift: student.shift || '', stream: student.stream || '', medium: student.medium || '' });
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to permanently delete this student?')) {
      try { await studentAPI.delete(id); toast.success('Student deleted successfully'); fetchStudents(); }
      catch { toast.error('Error deleting student'); }
    }
  };

  const handleDeleteSelected = async () => {
    if (!selectedStudents.size) return;
    if (window.confirm(`Delete ${selectedStudents.size} selected students?`)) {
      try {
        await Promise.all(Array.from(selectedStudents).map(id => studentAPI.delete(id)));
        toast.success(`${selectedStudents.size} students deleted`);
        setSelectedStudents(new Set()); fetchStudents();
      } catch { toast.error('Error deleting some students'); }
    }
  };

  const toggleSelectAll = (ids: string[]) => {
    const allSelected = ids.every(id => selectedStudents.has(id));
    const newSelected = new Set(selectedStudents);
    ids.forEach(id => allSelected ? newSelected.delete(id) : newSelected.add(id));
    setSelectedStudents(newSelected);
  };

  const toggleSelectStudent = (id: string) => {
    const newSelected = new Set(selectedStudents);
    newSelected.has(id) ? newSelected.delete(id) : newSelected.add(id);
    setSelectedStudents(newSelected);
  };

  const toggleGroupExpand = (key: string) => {
    const newExpanded = new Set(expandedGroups);
    newExpanded.has(key) ? newExpanded.delete(key) : newExpanded.add(key);
    setExpandedGroups(newExpanded);
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const required = ['std', 'class_name', 'first_name', 'last_name', 'medium'];
    const missing = required.filter(f => !formData[f] || String(formData[f]).trim() === '');
    if (missing.length) { toast.error(`Please fill: ${missing.join(', ')}`); return; }
    if (Number(formData.std) >= 11 && !formData.stream) { toast.error('Stream is required for Std 11 & 12'); return; }
    try {
      const payload: any = { ...formData, fees: formData.fees ? Number(formData.fees) : 0 };
      if (selectedStudent) {
        await studentAPI.update(selectedStudent._id || selectedStudent.id, payload);
        toast.success('Student updated');
      } else {
        const res = await studentAPI.register(payload);
        toast.success(res?.data?.generated_password ? `Student added. Password: ${res.data.generated_password}` : 'Student added');
      }
      setShowModal(false); fetchStudents();
    } catch (err: any) {
      const data = err.response?.data;
      if (data?.message === 'Validation error' && data.errors) toast.error(Object.keys(data.errors).map(k => `${k}: ${data.errors[k]}`).join(' | '));
      else toast.error(data?.message || 'Error saving student');
    }
  };

  const clearFilters = () => {
    setSearchTerm(''); setSelectedClassFilter(''); setSelectedStdFilter('');
    setSelectedShiftFilter(''); setSelectedMediumFilter('');
    setSelectedStudents(new Set()); setExpandedGroups(new Set());
  };

  const groupedStudents = filteredStudents.reduce((groups: any, student) => {
    const key = `${student.std}-${student.class_name}-${student.shift}-${student.medium}`;
    if (!groups[key]) groups[key] = { std: student.std, class_name: student.class_name, shift: student.shift, medium: student.medium, students: [] };
    groups[key].students.push(student);
    return groups;
  }, {});

  const streamOptions = getStreamOptions(formData.std);

  const avatarColors = [
    { bg: '#002B5B15', color: '#002B5B' },
    { bg: '#10B98115', color: '#065F46' },
    { bg: '#FFC10720', color: '#92400E' },
    { bg: '#3b82f615', color: '#1e40af' },
    { bg: '#8b5cf615', color: '#5b21b6' },
  ];

  const getGenderColor = (gender: string) => gender === 'Male' ? '#1d4ed8' : gender === 'Female' ? '#be185d' : '#6B7280';

  // ─── LOADING ───────────────────────────────────────────────
  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: themeConfig.background }}>
        <StudentStyleSheet />
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', border: '4px solid #e5e7eb', borderTopColor: themeConfig.primary, animation: 'spin 1s linear infinite', margin: '0 auto 12px' }} className="spinner" />
          <p style={{ color: '#6B7280', fontWeight: 500, fontSize: 14 }}>Loading students...</p>
        </div>
      </div>
    );
  }

  // ─── MOBILE VIEW ───────────────────────────────────────────
  const MobileView = () => (
    <div style={{ background: '#F0F2F5', minHeight: '100vh', paddingBottom: '68px' }}>

      {/* Navy Header */}
      <div style={{ background: 'linear-gradient(135deg, #002B5B 0%, #1a4a8a 55%, #2D54A8 100%)', padding: '16px 16px 20px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -40, right: -30, width: 130, height: 130, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
        <div style={{ position: 'absolute', top: 30, right: 50, width: 60, height: 60, borderRadius: '50%', background: 'rgba(255,255,255,0.04)' }} />

        {/* Top Row */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16px', position: 'relative' }}>
          <div>
            <p style={{ color: '#93C5FD', fontSize: '10px', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', margin: 0 }}>STUDENT PANEL</p>
            <h1 style={{ color: '#fff', fontSize: '22px', fontWeight: 800, margin: '2px 0 0', letterSpacing: '-0.3px' }}>Students</h1>
            <p style={{ color: 'rgba(147,197,253,0.8)', fontSize: '11px', margin: '2px 0 0' }}>Manage all students</p>
          </div>
          <div style={{ display: 'flex', gap: '7px' }}>
            <button onClick={openBulkModal} style={{ background: 'rgba(255,255,255,0.14)', border: '1px solid rgba(255,255,255,0.22)', borderRadius: '10px', color: '#fff', fontSize: '11px', fontWeight: 600, padding: '7px 11px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" /></svg>
              Bulk
            </button>
            <button onClick={openAddModal} style={{ background: '#FFC107', border: 'none', borderRadius: '10px', color: '#002B5B', fontSize: '11px', fontWeight: 700, padding: '7px 13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#002B5B" strokeWidth="2.5" strokeLinecap="round" /></svg>
              Add
            </button>
          </div>
        </div>

        {/* Stats 2x2 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', position: 'relative' }}>
          {[
            {
              label: 'TOTAL STUDENTS', value: students.length, color: '#fff', iconBg: 'rgba(255,255,255,0.18)',
              icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="9" cy="7" r="4" stroke="#fff" strokeWidth="2" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke="#fff" strokeWidth="2" strokeLinecap="round" /></svg>
            },
            {
              label: 'ACTIVE NOW', value: students.filter(s => s.is_active).length, color: '#fff', iconBg: 'rgba(255,255,255,0.18)',
              icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M22 10v6M2 10l10-5 10 5-10 5z" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M6 12v5c3 3 9 3 12 0v-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            },
            {
              label: 'MALE', value: students.filter(s => s.gender === 'Male').length, color: '#fff', iconBg: 'rgba(255,255,255,0.18)',
              icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="10" cy="14" r="6" stroke="#fff" strokeWidth="2" /><path d="M20 4l-6 6M14 4h6v6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            },
            {
              label: 'FEMALE', value: students.filter(s => s.gender === 'Female').length, color: '#fff', iconBg: 'rgba(255,255,255,0.18)',
              icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="6" stroke="#fff" strokeWidth="2" /><path d="M12 14v7M9 18h6" stroke="#fff" strokeWidth="2" strokeLinecap="round" /></svg>
            },
          ].map(({ label, value, color, iconBg, icon }) => (
            <div key={label} style={{ background: 'rgba(255,255,255,0.10)', borderRadius: '12px', padding: '10px 12px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '34px', height: '34px', borderRadius: '9px', background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{icon}</div>
              <div>
                <p style={{ color, fontSize: '18px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{value}</p>
                <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '9px', fontWeight: 700, margin: '2px 0 0', letterSpacing: '0.05em' }}>{label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search */}
      <div style={{ padding: '12px 12px 0' }}>
        <div style={{ background: '#fff', borderRadius: '10px', border: '1px solid #e5e7eb', padding: '8px 12px', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="8" stroke="#9CA3AF" strokeWidth="2" /><path d="M21 21l-4.35-4.35" stroke="#9CA3AF" strokeWidth="2" strokeLinecap="round" /></svg>
          <input type="text" placeholder="Search by name or GR..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} style={{ border: 'none', outline: 'none', fontSize: '13px', color: '#374151', flex: 1, background: 'transparent' }} />
          {searchTerm && <button onClick={() => setSearchTerm('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF', fontSize: '18px', padding: 0, lineHeight: 1 }}>×</button>}
        </div>

        {/* Filter chips */}
        <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '10px' }}>
          {[
            { label: 'All', active: !selectedStdFilter && !selectedClassFilter && !selectedShiftFilter && !selectedMediumFilter, onClick: clearFilters },
            ...getUniqueStandards().map(s => ({ label: `Std ${s}`, active: selectedStdFilter === s, onClick: () => setSelectedStdFilter(selectedStdFilter === s ? '' : s) })),
            ...getUniqueClasses().map(c => ({ label: `Sec ${c}`, active: selectedClassFilter === c, onClick: () => setSelectedClassFilter(selectedClassFilter === c ? '' : c) })),
            ...getUniqueShifts().map(s => ({ label: s, active: selectedShiftFilter === s, onClick: () => setSelectedShiftFilter(selectedShiftFilter === s ? '' : s) })),
            ...getUniqueMediums().map(m => ({ label: m, active: selectedMediumFilter === m, onClick: () => setSelectedMediumFilter(selectedMediumFilter === m ? '' : m) })),
          ].map(({ label, active, onClick }) => (
            <button key={label} onClick={onClick} style={{ flexShrink: 0, padding: '5px 12px', borderRadius: '999px', fontSize: '11px', fontWeight: 600, border: active ? 'none' : '1px solid #e5e7eb', cursor: 'pointer', background: active ? '#002B5B' : '#fff', color: active ? '#fff' : '#6B7280', whiteSpace: 'nowrap' }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Student List */}
      <div style={{ padding: '0 12px' }}>
        <p style={{ fontSize: '11px', fontWeight: 700, color: '#9CA3AF', letterSpacing: '0.05em', textTransform: 'uppercase', margin: '0 0 8px 2px' }}>
          {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''}
        </p>

        {filteredStudents.length === 0 ? (
          <div style={{ background: '#fff', borderRadius: '12px', padding: '36px 24px', textAlign: 'center' }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" style={{ margin: '0 auto 10px', display: 'block' }}>
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="9" cy="7" r="4" stroke="#D1D5DB" strokeWidth="2" />
            </svg>
            <p style={{ fontWeight: 700, color: '#374151', fontSize: '13px', margin: '0 0 4px' }}>No students found</p>
            <p style={{ color: '#9CA3AF', fontSize: '11px', margin: 0 }}>Try adjusting your filters</p>
          </div>
        ) : (
          filteredStudents.map((student, index) => {
            const ac = avatarColors[index % avatarColors.length];
            const initials = `${student.first_name?.charAt(0) || ''}${student.last_name?.charAt(0) || ''}`;
            return (
              <div key={student._id || student.id} style={{ background: '#fff', borderRadius: '12px', border: '1px solid #e5e7eb', marginBottom: '8px', overflow: 'hidden' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: ac.bg, color: ac.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 800, flexShrink: 0 }}>
                    {initials}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: '13px', fontWeight: 700, color: '#111827', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {student.first_name} {student.last_name}
                    </p>
                    <p style={{ fontSize: '10px', color: '#9CA3AF', margin: '1px 0 0', fontFamily: 'monospace' }}>
                      GR: {student.gr_number} · Roll: {student.roll_no}
                    </p>
                    <p style={{ fontSize: '10px', color: '#6B7280', margin: '1px 0 0' }}>
                      Std {student.std} · {student.class_name} · {student.shift} · {student.medium}
                    </p>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '5px', flexShrink: 0 }}>
                    <span style={{ padding: '2px 8px', borderRadius: '999px', fontSize: '10px', fontWeight: 600, background: student.is_active ? '#D1FAE5' : '#FEE2E2', color: student.is_active ? '#065F46' : '#991B1B' }}>
                      {student.is_active ? 'Active' : 'Inactive'}
                    </span>
                    <span style={{ fontSize: '10px', fontWeight: 600, color: getGenderColor(student.gender) }}>
                      {student.gender || '—'}
                    </span>
                  </div>
                </div>
                <div style={{ borderTop: '1px solid #f3f4f6', padding: '6px 12px', display: 'flex', gap: '6px' }}>
                  {[
                    { label: 'History', bg: `${themeConfig.primary}12`, color: themeConfig.primary, onClick: () => navigate(`/admin/student-history/${student._id || student.id}`), icon: <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke={themeConfig.primary} strokeWidth="2" /><path d="M12 6v6l4 2" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /></svg> },
                    { label: 'Edit', bg: `${themeConfig.info}12`, color: themeConfig.info, onClick: () => openEditModal(student), icon: <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke={themeConfig.info} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke={themeConfig.info} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg> },
                    { label: 'Delete', bg: `${themeConfig.danger}12`, color: themeConfig.danger, onClick: () => handleDelete(student._id || student.id), icon: <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><polyline points="3 6 5 6 21 6" stroke={themeConfig.danger} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke={themeConfig.danger} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M10 11v6M14 11v6M9 6V4h6v2" stroke={themeConfig.danger} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg> },
                  ].map(({ label, bg, color, onClick, icon }) => (
                    <button key={label} onClick={onClick} style={{ flex: 1, height: '28px', borderRadius: '8px', border: 'none', fontSize: '10px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', background: bg, color }}>
                      {icon}{label}
                    </button>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Navigation */}
      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderTop: '1px solid #e5e7eb', display: 'flex', height: '60px', zIndex: 50 }}>
        {[
          {
            label: 'Dashboard', path: '/admin/dashboard', active: false,
            icon: (active: boolean) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="7" height="7" rx="1.5" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><rect x="14" y="3" width="7" height="7" rx="1.5" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><rect x="3" y="14" width="7" height="7" rx="1.5" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><rect x="14" y="14" width="7" height="7" rx="1.5" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /></svg>,
          },
          {
            label: 'Students', path: '/admin/students', active: true,
            icon: (active: boolean) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /><circle cx="9" cy="7" r="4" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" strokeLinecap="round" /></svg>,
          },
          {
            label: 'Attendance', path: '/admin/attendance', active: false,
            icon: (active: boolean) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="18" rx="2" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><path d="M16 2v4M8 2v4M3 10h18" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" strokeLinecap="round" /></svg>,
          },
          {
            label: 'Fees', path: '/admin/fees', active: false,
            icon: (active: boolean) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="2" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" /><path d="M2 10h20" stroke={active ? themeConfig.primary : '#9CA3AF'} strokeWidth="1.8" strokeLinecap="round" /></svg>,
          },
          {
            label: 'Add', onClick: openAddModal, active: false, isAdd: true,
            icon: (_: boolean) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#002B5B" strokeWidth="2.5" strokeLinecap="round" /></svg>,
          },
        ].map(({ label, path, active, icon, onClick, isAdd }: any) => (
          <button key={label} onClick={onClick || (() => navigate(path))} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '3px', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            {isAdd ? (
              <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: '#FFC107', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {icon(active)}
              </div>
            ) : icon(active)}
            <span style={{ fontSize: '9px', fontWeight: 600, color: active ? themeConfig.primary : '#9CA3AF' }}>{label}</span>
          </button>
        ))}
      </div>
    </div>
  );

  // ─── DESKTOP VIEW ──────────────────────────────────────────
  const DesktopView = () => (
    <>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-3 sm:p-4 rounded-xl shadow-sm border border-gray-100" style={{ margin: '20px 20px 0', borderRadius: '12px' }}>
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-lg sm:text-xl font-black tracking-tight" style={{ color: themeConfig.primary, margin: 0 }}>Students Management</h1>
            <p className="text-[10px] sm:text-xs font-medium" style={{ color: themeConfig.textSecondary, margin: '4px 0 0' }}>Manage and organize all students in your school</p>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2">
          <button 
            onClick={openBulkModal} 
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-white text-[10px] sm:text-xs font-bold shadow-md transition-all active:scale-95 hover:brightness-110"
            style={{ backgroundColor: themeConfig.secondary }}
          >
            <FaPlus />
            <span>Bulk Add</span>
          </button>
          <button 
            onClick={openAddModal} 
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-white text-[10px] sm:text-xs font-bold shadow-md transition-all active:scale-95 hover:brightness-110"
            style={{ backgroundColor: themeConfig.primary }}
          >
            <FaPlus />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '20px 20px 32px' }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px', marginBottom: '20px' }}>
          {[
            { label: 'TOTAL', value: students.length, sub: 'Students', color: themeConfig.primary, iconBg: `${themeConfig.primary}18`, icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><circle cx="9" cy="7" r="4" stroke={themeConfig.primary} strokeWidth="2" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /><path d="M16 3.13a4 4 0 0 1 0 7.75" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /></svg> },
            { label: 'ACTIVE', value: students.filter(s => s.is_active).length, sub: 'Enrolled', color: themeConfig.primary, iconBg: `${themeConfig.primary}18`, icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M22 10v6M2 10l10-5 10 5-10 5z" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M6 12v5c3 3 9 3 12 0v-5" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg> },
            { label: 'MALE', value: students.filter(s => s.gender === 'Male').length, sub: 'Students', color: themeConfig.primary, iconBg: `${themeConfig.primary}18`, icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="10" cy="14" r="6" stroke={themeConfig.primary} strokeWidth="2" /><path d="M20 4l-6 6" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /><path d="M14 4h6v6" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg> },
            { label: 'FEMALE', value: students.filter(s => s.gender === 'Female').length, sub: 'Students', color: themeConfig.primary, iconBg: `${themeConfig.primary}18`, icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="6" stroke={themeConfig.primary} strokeWidth="2" /><path d="M12 14v7" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /><path d="M9 18h6" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" /></svg> },
          ].map(({ label, value, sub, color, iconBg, icon }) => (
            <div key={label} style={{ background: 'white', borderRadius: '12px', padding: '14px 18px', border: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
              <div>
                <p style={{ fontSize: '11px', fontWeight: 700, color: '#9CA3AF', letterSpacing: '0.07em', textTransform: 'uppercase', margin: 0 }}>{label}</p>
                <p style={{ fontSize: '22px', fontWeight: 800, color, margin: '2px 0' }}>{value}</p>
                <p style={{ fontSize: '11px', color: '#9CA3AF', margin: 0 }}>{sub}</p>
              </div>
              <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{icon}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ background: 'white', borderRadius: '12px', border: '1px solid #e5e7eb', padding: '14px 18px', marginBottom: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: `${themeConfig.primary}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" stroke={themeConfig.primary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
              <div>
                <p style={{ fontSize: '13px', fontWeight: 700, color: '#1F2937', margin: 0 }}>Filters & Search</p>
                <p style={{ fontSize: '11px', color: '#9CA3AF', margin: 0 }}>Find students quickly</p>
              </div>
            </div>
            {(searchTerm || selectedClassFilter || selectedStdFilter || selectedShiftFilter || selectedMediumFilter) && (
              <button onClick={clearFilters} style={{ fontSize: '11px', fontWeight: 600, color: themeConfig.primary, background: `${themeConfig.primary}10`, border: `1.5px solid ${themeConfig.primary}`, borderRadius: '8px', padding: '5px 12px', cursor: 'pointer' }}>Clear All</button>
            )}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr', gap: '8px' }}>
            <input type="text" placeholder="Search by name or GR..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} style={{ padding: '6px 10px', border: '1.5px solid #e5e7eb', borderRadius: '8px', fontSize: '12px', outline: 'none', width: '100%', boxSizing: 'border-box' as any }} />
            {[
              { value: selectedStdFilter, onChange: setSelectedStdFilter, placeholder: 'All Standards', options: getUniqueStandards().map(s => ({ v: s, l: `Class ${s}` })) },
              { value: selectedClassFilter, onChange: setSelectedClassFilter, placeholder: 'All Sections', options: getUniqueClasses().map(c => ({ v: c, l: `Section ${c}` })) },
              { value: selectedShiftFilter, onChange: setSelectedShiftFilter, placeholder: 'All Shifts', options: getUniqueShifts().map(s => ({ v: s, l: s })) },
              { value: selectedMediumFilter, onChange: setSelectedMediumFilter, placeholder: 'All Mediums', options: getUniqueMediums().map(m => ({ v: m, l: m })) },
            ].map(({ value, onChange, placeholder, options }, i) => (
              <select key={i} value={value} onChange={e => onChange(e.target.value)} style={{ padding: '6px 10px', border: '1.5px solid #e5e7eb', borderRadius: '8px', fontSize: '12px', outline: 'none', width: '100%', background: 'white' }}>
                <option value="">{placeholder}</option>
                {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
              </select>
            ))}
          </div>
          {(searchTerm || selectedClassFilter || selectedStdFilter || selectedShiftFilter || selectedMediumFilter) && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '10px', paddingTop: '10px', borderTop: '1px solid #f3f4f6' }}>
              {[
                { label: `Class ${selectedStdFilter}`, show: !!selectedStdFilter, clear: () => setSelectedStdFilter(''), color: '#1d4ed8', bg: '#3b82f615' },
                { label: `Section ${selectedClassFilter}`, show: !!selectedClassFilter, clear: () => setSelectedClassFilter(''), color: themeConfig.primary, bg: `${themeConfig.primary}12` },
                { label: selectedShiftFilter, show: !!selectedShiftFilter, clear: () => setSelectedShiftFilter(''), color: '#1d4ed8', bg: '#3b82f615' },
                { label: selectedMediumFilter, show: !!selectedMediumFilter, clear: () => setSelectedMediumFilter(''), color: '#059669', bg: '#10B98115' },
                { label: `"${searchTerm}"`, show: !!searchTerm, clear: () => setSearchTerm(''), color: '#1d4ed8', bg: '#3b82f615' },
              ].filter(b => b.show).map(({ label, clear, color, bg }) => (
                <span key={label} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '999px', fontSize: '11px', fontWeight: 600, background: bg, color }}>
                  {label} <button onClick={clear} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'inherit', padding: 0, lineHeight: 1 }}>×</button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        {filteredStudents.length === 0 ? (
          <div style={{ background: 'white', borderRadius: '12px', border: '1px solid #e5e7eb', padding: '48px', textAlign: 'center' }}>
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" style={{ margin: '0 auto 12px', display: 'block' }}>
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="9" cy="7" r="4" stroke="#D1D5DB" strokeWidth="2" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <p style={{ fontWeight: 700, color: '#1F2937', fontSize: '14px', margin: '0 0 4px' }}>No students found</p>
            <p style={{ color: '#9CA3AF', fontSize: '12px', margin: 0 }}>Try adjusting your filters or add a new student</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {Object.entries(groupedStudents).map(([groupKey, group]: [string, any]) => {
              const groupStudentIds = group.students.map((s: any) => s._id || s.id);
              const isGroupAllSelected = groupStudentIds.every((id: string) => selectedStudents.has(id));
              const isExpanded = expandedGroups.has(groupKey);
              return (
                <div key={groupKey} style={{ background: 'white', borderRadius: '12px', border: '1px solid #e5e7eb', overflow: 'hidden' }}>
                  <div style={{ padding: '10px 16px', cursor: 'pointer', background: `${themeConfig.primary}05`, borderBottom: isExpanded ? '1px solid #e5e7eb' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }} onClick={() => toggleGroupExpand(groupKey)}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
                      <input type="checkbox" checked={isGroupAllSelected} onChange={() => toggleSelectAll(groupStudentIds)} onClick={e => e.stopPropagation()} style={{ width: '15px', height: '15px', cursor: 'pointer', flexShrink: 0 }} />
                      <div style={{ minWidth: 0 }}>
                        <p style={{ fontWeight: 700, fontSize: '13px', color: themeConfig.primary, margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          Class {group.std} · Section {group.class_name} · {group.shift} · {group.medium}
                        </p>
                        <p style={{ fontSize: '11px', color: '#9CA3AF', margin: 0 }}>{group.students.length} students</p>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
                      {selectedStudents.size > 0 && groupStudentIds.some((id: string) => selectedStudents.has(id)) && (
                        <button onClick={e => { e.stopPropagation(); handleDeleteSelected(); }} style={{ fontSize: '11px', fontWeight: 600, color: themeConfig.danger, background: `${themeConfig.danger}10`, border: `1.5px solid ${themeConfig.danger}`, borderRadius: '8px', padding: '4px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <FaTrash size={10} /> Delete ({groupStudentIds.filter((id: string) => selectedStudents.has(id)).length})
                        </button>
                      )}
                      <FaChevronDown size={12} color="#9CA3AF" style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }} />
                    </div>
                  </div>
                  {isExpanded && (
                    <div style={{ overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid #f3f4f6', background: `${themeConfig.primary}03` }}>
                            {['', 'Roll', 'GR Number', 'Student Name', 'Gender', 'Status', 'Actions'].map((h, i) => (
                              <th key={i} style={{ padding: '8px 12px', textAlign: i === 6 ? 'right' : 'left', fontWeight: 700, color: '#6B7280', fontSize: '11px' }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {group.students.map((student: any) => {
                            const isSelected = selectedStudents.has(student._id || student.id);
                            return (
                              <tr key={student._id || student.id} style={{ borderBottom: '1px solid #f9fafb', background: isSelected ? `${themeConfig.primary}08` : 'white' }}
                                onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = '#f9fafb'; }}
                                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = isSelected ? `${themeConfig.primary}08` : 'white'; }}>
                                <td style={{ padding: '7px 12px' }}><input type="checkbox" checked={isSelected} onChange={() => toggleSelectStudent(student._id || student.id)} style={{ width: '14px', height: '14px', cursor: 'pointer' }} /></td>
                                <td style={{ padding: '7px 12px', fontWeight: 600, color: '#1F2937' }}>{student.roll_no}</td>
                                <td style={{ padding: '7px 12px', color: '#6B7280', fontFamily: 'monospace', fontSize: '11px' }}>{student.gr_number}</td>
                                <td style={{ padding: '7px 12px' }}>
                                  <div style={{ fontWeight: 600, color: '#1F2937', fontSize: '12px' }}>{student.first_name} {student.last_name}</div>
                                  <div style={{ fontSize: '11px', color: '#9CA3AF' }}>{student.phone1}</div>
                                </td>
                                <td style={{ padding: '7px 12px' }}>
                                  <span style={{ fontSize: '12px', color: getGenderColor(student.gender), fontWeight: 600 }}>{student.gender}</span>
                                </td>
                                <td style={{ padding: '7px 12px' }}>
                                  <span style={{ display: 'inline-flex', alignItems: 'center', padding: '2px 8px', borderRadius: '999px', fontSize: '11px', fontWeight: 600, background: student.is_active ? '#10B98115' : '#EF444415', color: student.is_active ? '#1F2937' : '#1F2937' }}>
                                    {student.is_active ? 'Active' : 'Inactive'}
                                  </span>
                                </td>
                                <td style={{ padding: '7px 12px' }}>
                                  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '6px' }}>
                                    {[
                                      { title: 'History', bg: `${themeConfig.primary}10`, color: themeConfig.primary, onClick: () => navigate(`/admin/student-history/${student._id || student.id}`), icon: <FaHistory size={12} /> },
                                      { title: 'Edit', bg: `${themeConfig.info}10`, color: themeConfig.info, onClick: () => openEditModal(student), icon: <FaEdit size={12} /> },
                                      { title: 'Delete', bg: `${themeConfig.danger}10`, color: themeConfig.danger, onClick: () => handleDelete(student._id || student.id), icon: <FaTrash size={12} /> },
                                    ].map(({ title, bg, color, onClick, icon }) => (
                                      <button key={title} onClick={onClick} title={title} style={{ width: '28px', height: '28px', borderRadius: '7px', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', background: bg, color }}>
                                        {icon}
                                      </button>
                                    ))}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );

  // ─── MODALS ────────────────────────────────────────────────
  const AddEditModal = () => (
    <div className="modal-overlay">
      <div className="modal-content">
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: themeConfig.primary }}>{selectedStudent ? 'Edit Student' : 'Add New Student'}</h3>
          <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#9CA3AF', lineHeight: 1 }}>✕</button>
        </div>
        <form onSubmit={handleFormSubmit} style={{ padding: '20px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            {/* Standard */}
            <div className="select-wrapper">
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Standard <span style={{ color: 'red' }}>*</span></label>
              <select name="std" value={formData.std} onChange={handleFormChange} className="input-field" required>
                <option value="">Select Standard</option>
                {['1','2','3','4','5','6','7','8','9','10','11','12'].map(s => <option key={s} value={s}>Class {s}</option>)}
              </select>
            </div>
            {/* Section */}
            <div className="select-wrapper">
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Section <span style={{ color: 'red' }}>*</span></label>
              <select name="class_name" value={formData.class_name} onChange={handleFormChange} className="input-field" required>
                <option value="">Select Section</option>
                {['A','B','C','D'].map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            {/* First Name */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>First Name <span style={{ color: 'red' }}>*</span></label>
              <input name="first_name" value={formData.first_name} onChange={handleFormChange} placeholder="Enter first name" className="input-field" required />
            </div>
            {/* Middle Name */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Middle Name</label>
              <input name="middle_name" value={formData.middle_name} onChange={handleFormChange} placeholder="Enter middle name" className="input-field" />
            </div>
            {/* Last Name */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Last Name <span style={{ color: 'red' }}>*</span></label>
              <input name="last_name" value={formData.last_name} onChange={handleFormChange} placeholder="Enter last name" className="input-field" required />
            </div>
            {/* Medium */}
            <div className="select-wrapper">
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Medium <span style={{ color: 'red' }}>*</span></label>
              <select name="medium" value={formData.medium} onChange={handleFormChange} className="input-field" required>
                <option value="">Select Medium</option>
                <option value="English">English</option>
                <option value="Gujarati">Gujarati</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>
            {/* Gender */}
            <div className="select-wrapper">
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Gender</label>
              <select name="gender" value={formData.gender} onChange={handleFormChange} className="input-field">
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
            {/* Stream */}
            {streamOptions.length > 0 && (
              <div className="select-wrapper">
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Stream {Number(formData.std) >= 11 && <span style={{ color: 'red' }}>*</span>}</label>
                <select name="stream" value={formData.stream} onChange={handleFormChange} className="input-field" required={Number(formData.std) >= 11}>
                  <option value="">Select Stream</option>
                  {streamOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
            )}
            {/* Shift */}
            <div className="select-wrapper">
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Shift</label>
              <select name="shift" value={formData.shift} onChange={handleFormChange} className="input-field">
                <option value="">Select Shift</option>
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
              </select>
            </div>
            {/* Phone 1 */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Primary Phone</label>
              <input name="phone1" value={formData.phone1} onChange={handleFormChange} placeholder="Enter primary phone" className="input-field" />
            </div>
            {/* Phone 2 */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Secondary Phone</label>
              <input name="phone2" value={formData.phone2} onChange={handleFormChange} placeholder="Enter secondary phone" className="input-field" />
            </div>
            {/* PIN */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>PIN Code</label>
              <input name="pin" value={formData.pin} onChange={handleFormChange} placeholder="Enter PIN code" className="input-field" />
            </div>
            {/* Fees */}
            <div>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Fees Amount</label>
              <input name="fees" value={formData.fees} onChange={handleFormChange} placeholder="Enter fees amount" type="number" className="input-field" />
            </div>
            {/* Password */}
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Password</label>
              <div style={{ position: 'relative' }}>
                <input name="password" value={formData.password} onChange={handleFormChange} placeholder="Leave empty for auto-generate" type={showPassword ? 'text' : 'password'} className="input-field" style={{ paddingRight: '2.5rem' }} />
                <button type="button" onClick={() => setShowPassword(!showPassword)} style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF' }}>
                  {showPassword ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
              </div>
              <p style={{ fontSize: '11px', color: '#9CA3AF', margin: '4px 0 0' }}>Optional — leave blank to auto-generate</p>
            </div>
            {/* Address */}
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#374151', marginBottom: '4px' }}>Address</label>
              <textarea name="address" value={formData.address} onChange={handleFormChange} placeholder="Enter address" className="input-field" style={{ resize: 'none', height: '72px' }} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', paddingTop: '16px', borderTop: '1px solid #e5e7eb', marginTop: '16px' }}>
            <button type="button" onClick={() => setShowModal(false)} className="btn-base btn-secondary">Cancel</button>
            <button type="submit" className="btn-base btn-primary">Save Student</button>
          </div>
        </form>
      </div>
    </div>
  );

  const BulkModal = () => (
    <div className="modal-overlay">
      <div className="modal-content">
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#1F2937', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FaTable style={{ color: themeConfig.primary }} /> Bulk Student Creator
          </h3>
          <button onClick={() => setShowBulkModal(false)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#9CA3AF' }}>✕</button>
        </div>
        <div style={{ padding: '20px', overflowY: 'auto', maxHeight: 'calc(90vh - 140px)' }} className="custom-scrollbar">
          {/* Default Settings */}
          <div style={{ background: `${themeConfig.primary}08`, border: `1px solid ${themeConfig.primary}20`, borderRadius: '10px', padding: '14px', marginBottom: '16px' }}>
            <p style={{ fontSize: '12px', fontWeight: 700, color: '#1F2937', margin: '0 0 10px' }}>Default Settings</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '8px' }}>
              {[
                { key: 'std', label: 'Standard *', options: ['1','2','3','4','5','6','7','8','9','10','11','12'] },
                { key: 'class_name', label: 'Class *', options: ['A','B','C','D'] },
                { key: 'shift', label: 'Shift', options: ['Morning','Afternoon'] },
                { key: 'medium', label: 'Medium *', options: ['English','Gujarati','Hindi'] },
                { key: 'gender', label: 'Gender', options: ['Male','Female','Other'] },
              ].map(field => (
                <div key={field.key}>
                  <label style={{ fontSize: '10px', fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', display: 'block', marginBottom: '3px' }}>{field.label}</label>
                  <select value={bulkApplyAll[field.key]} onChange={e => setBulkApplyAll({ ...bulkApplyAll, [field.key]: e.target.value })} className="input-field" style={{ fontSize: '11px', padding: '5px 8px' }}>
                    <option value="">Select</option>
                    {field.options.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>
          {/* Paste Area */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', fontWeight: 700, color: '#374151', display: 'block', marginBottom: '6px' }}>Paste Student Data</label>
            <textarea value={bulkInputText} onChange={e => setBulkInputText(e.target.value)} onPaste={handlePaste} placeholder="Example: First Name: Aarav | Last Name: Patel | Phone1: 9876543210" className="input-field" style={{ minHeight: '90px', fontFamily: 'monospace', fontSize: '11px', resize: 'none' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '6px' }}>
              <span style={{ fontSize: '11px', color: '#9CA3AF' }}>{bulkInputText.split('\n').filter(l => l.trim()).length} rows detected</span>
              <button onClick={handleAddToList} className="btn-base btn-primary" style={{ padding: '5px 12px', fontSize: '11px' }}>+ Add to List</button>
            </div>
          </div>
          {/* Table */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
              <div>
                <p style={{ fontSize: '12px', fontWeight: 700, color: '#1F2937', margin: 0 }}>{bulkRows.length} Student(s)</p>
                <p style={{ fontSize: '11px', color: '#9CA3AF', margin: 0 }}>Fill in student details below</p>
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button onClick={() => setBulkRows([])} style={{ fontSize: '11px', color: themeConfig.danger, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>Clear All</button>
                <button onClick={addBulkRow} className="btn-base btn-secondary" style={{ padding: '5px 10px', fontSize: '11px' }}><FaPlus size={10} /> Add Row</button>
              </div>
            </div>
            <div style={{ border: '1px solid #e5e7eb', borderRadius: '8px', overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px' }}>
                <thead style={{ background: `${themeConfig.primary}05` }}>
                  <tr style={{ borderBottom: '1px solid #e5e7eb' }}>
                    {['#', 'First *', 'Last *', 'Phone', 'Std *', 'Class *', 'Medium *', ''].map((h, i) => (
                      <th key={i} style={{ padding: '7px 10px', textAlign: i === 7 ? 'center' : 'left', fontWeight: 700, color: '#6B7280', fontSize: '10px' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bulkRows.map((row, idx) => (
                    <tr key={idx} style={{ borderBottom: '1px solid #f3f4f6' }}>
                      <td style={{ padding: '5px 10px', color: '#9CA3AF' }}>{idx + 1}</td>
                      <td style={{ padding: '4px 6px' }}><input value={row.first_name} onChange={e => handleBulkRowChange(idx, 'first_name', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px' }} /></td>
                      <td style={{ padding: '4px 6px' }}><input value={row.last_name} onChange={e => handleBulkRowChange(idx, 'last_name', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px' }} /></td>
                      <td style={{ padding: '4px 6px' }}><input value={row.phone1} onChange={e => handleBulkRowChange(idx, 'phone1', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px', fontFamily: 'monospace' }} /></td>
                      <td style={{ padding: '4px 6px' }}>
                        <select value={row.std} onChange={e => handleBulkRowChange(idx, 'std', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px' }}>
                          {['1','2','3','4','5','6','7','8','9','10','11','12'].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                      <td style={{ padding: '4px 6px' }}>
                        <select value={row.class_name} onChange={e => handleBulkRowChange(idx, 'class_name', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px' }}>
                          {['A','B','C','D'].map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </td>
                      <td style={{ padding: '4px 6px' }}>
                        <select value={row.medium} onChange={e => handleBulkRowChange(idx, 'medium', e.target.value)} className="input-field" style={{ fontSize: '11px', padding: '4px 6px' }}>
                          {['English','Gujarati','Hindi'].map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                      </td>
                      <td style={{ padding: '5px 10px', textAlign: 'center' }}>
                        <button onClick={() => removeBulkRow(idx)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: themeConfig.danger }}><FaTrash size={11} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {bulkRows.length === 0 && (
              <div style={{ textAlign: 'center', padding: '28px', border: '2px dashed #e5e7eb', borderRadius: '8px', marginTop: '8px' }}>
                <p style={{ color: '#9CA3AF', fontSize: '12px', margin: 0 }}>No students added yet</p>
              </div>
            )}
          </div>
          {/* Results */}
          {bulkResults && (
            <div style={{ marginTop: '14px', padding: '12px 14px', borderRadius: '8px', border: `1px solid ${bulkResults.success ? '#D1FAE5' : '#FEE2E2'}`, background: bulkResults.success ? '#F0FDF4' : '#FEF2F2' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                {bulkResults.success ? <FaCheck style={{ color: '#16A34A' }} /> : <FaTimes style={{ color: '#DC2626' }} />}
                <span style={{ fontWeight: 700, fontSize: '12px', color: bulkResults.success ? '#15803D' : '#B91C1C' }}>
                  {bulkResults.success ? `Created ${bulkResults.count} students` : 'Creation failed'}
                </span>
              </div>
              {bulkResults.errors?.length > 0 && (
                <div style={{ fontSize: '11px', color: '#B91C1C', maxHeight: '100px', overflowY: 'auto' }}>
                  {bulkResults.errors.map((err: any, i: number) => <p key={i} style={{ margin: '2px 0' }}>Row {err.index + 1}: {err.message}</p>)}
                </div>
              )}
            </div>
          )}
        </div>
        <div style={{ padding: '14px 20px', borderTop: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
          <span style={{ fontSize: '11px', color: '#9CA3AF' }}>Ready: {bulkRows.filter(r => r.first_name && r.last_name && r.std && r.medium).length} students</span>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button onClick={() => setShowBulkModal(false)} className="btn-base btn-secondary">Cancel</button>
            <button onClick={handleBulkSubmit} disabled={bulkSubmitting || !bulkRows.length} className="btn-base btn-primary" style={{ opacity: (bulkSubmitting || !bulkRows.length) ? 0.5 : 1 }}>
              {bulkSubmitting ? 'Creating...' : 'Create Students'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // ─── RENDER ────────────────────────────────────────────────
  return (
    <div className="student-container">
      <StudentStyleSheet />
      {isMobile ? <MobileView /> : <DesktopView />}
      {showModal && <AddEditModal />}
      {showBulkModal && <BulkModal />}
    </div>
  );
};

export default Students;