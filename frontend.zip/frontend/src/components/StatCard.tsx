import React from 'react';

const StatCard = ({ title, value, icon: Icon, color = 'blue', subtitle = '' }) => {
  const colors = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    red: 'bg-red-50 text-red-600 border-red-200',
    yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200',
    teal: 'bg-teal-50 text-teal-600 border-teal-200',
  };
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 md:p-5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0 flex-1 text-left">
          <p className="text-[8px] md:text-sm text-gray-500 font-bold truncate uppercase tracking-widest">{title}</p>
          <p className="text-sm md:text-2xl font-black text-gray-900 mt-0.5">{value}</p>
          {subtitle && <p className="text-[7px] md:text-xs text-gray-400 mt-0.5 truncate leading-none">{subtitle}</p>}
        </div>
        {Icon && (
          <div className={`w-8 h-8 md:w-12 md:h-12 flex-shrink-0 rounded-lg md:rounded-xl flex items-center justify-center border ${colors[color]}`}>
            <Icon className="text-sm md:text-xl" />
          </div>
        )}
      </div>
    </div>
  );
};

export default StatCard;
