import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  UserSquare2,
  BookOpen,
  CalendarCheck2,
  ClipboardList,
  Wallet,
  Bell,
  CalendarDays,
  FileText,
  Clock,
  LogOut,
  User,
  School,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Settings,
  ShieldCheck,
  BookMarked,
  Presentation
} from 'lucide-react';

interface MenuItem {
  path?: string;
  icon: any;
  label: string;
  section: string;
  subItems?: { path: string; label: string }[];
}

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const { user, logout } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
    setOpenDropdown(null);
  };

  const toggleDropdown = (label: string) => {
    if (isCollapsed) setIsCollapsed(false);
    setOpenDropdown(openDropdown === label ? null : label);
  };

  const adminMenuItems: MenuItem[] = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard', section: 'main' },
    {
      label: 'User Management',
      icon: Users,
      section: 'management',
      subItems: [
        { path: '/admin/admins', label: 'Admins' },
        { path: '/admin/students', label: 'Students' },
        { path: '/admin/teachers', label: 'Teachers' },
      ]
    },
    {
      label: 'Academic Setup',
      icon: BookOpen,
      section: 'management',
      subItems: [
        { path: '/admin/classes', label: 'Classes' },
        { path: '/admin/subjects', label: 'Subjects' },
        { path: '/admin/subject-assignment', label: 'Subject Assignment' },
        { path: '/admin/assign-class-teacher', label: 'Assign Teacher' },
      ]
    },
    { path: '/admin/attendance', icon: CalendarCheck2, label: 'Attendance', section: 'academic' },
    { path: '/admin/exams', icon: ClipboardList, label: 'Exams', section: 'academic' },
    { path: '/admin/fees', icon: Wallet, label: 'Fees Management', section: 'finance' },
    {
      label: 'Communication',
      icon: Bell,
      section: 'communication',
      subItems: [
        { path: '/admin/notices', label: 'Notices' },
        { path: '/admin/events', label: 'Events' },
        { path: '/admin/leaves', label: 'Leave Management' },
      ]
    },
    { path: '/admin/timetable', icon: Clock, label: 'Timetable', section: 'academic' },
    { path: '/admin/calendar', icon: CalendarDays, label: 'Holiday Calendar', section: 'academic' },
  ];

  const teacherMenuItems: MenuItem[] = [
    { path: '/teacher/dashboard', icon: LayoutDashboard, label: 'Dashboard', section: 'main' },
    { path: '/teacher/attendance', icon: CalendarCheck2, label: 'Attendance', section: 'academic' },
    { path: '/teacher/homework', icon: ClipboardList, label: 'Homework', section: 'academic' },
    { path: '/teacher/exams', icon: ClipboardList, label: 'Exams', section: 'academic' },
    { path: '/teacher/results', icon: FileText, label: 'Results', section: 'academic' },
    { path: '/teacher/timetable', icon: Clock, label: 'Timetable', section: 'academic' },
    {
      label: 'Communication',
      icon: Bell,
      section: 'communication',
      subItems: [
        { path: '/teacher/notices', label: 'Notices' },
        { path: '/teacher/events', label: 'Events' },
        { path: '/teacher/leaves', label: 'Student Leaves' },
        { path: '/teacher/leave', label: 'Leave Application' },
      ]
    },
  ];

  const studentMenuItems: MenuItem[] = [
    { path: '/student/dashboard', icon: LayoutDashboard, label: 'Dashboard', section: 'main' },
    { path: '/student/attendance', icon: CalendarCheck2, label: 'Attendance', section: 'academic' },
    { path: '/student/homework', icon: ClipboardList, label: 'Homework', section: 'academic' },
    { path: '/student/results', icon: FileText, label: 'Results', section: 'academic' },
    { path: '/student/fees', icon: Wallet, label: 'Fees', section: 'finance' },
    { path: '/student/timetable', icon: Clock, label: 'Timetable', section: 'academic' },
    { path: '/student/notices', icon: Bell, label: 'Notices & Events', section: 'communication' },
    { path: '/student/leave', icon: FileText, label: 'Leave Application', section: 'communication' },
  ];

  const getMenuItems = (): MenuItem[] => {
    if (user?.role === 'admin' || user?.role === 'sub_admin') return adminMenuItems;
    if (user?.role === 'teacher') return teacherMenuItems;
    if (user?.role === 'student') return studentMenuItems;
    return [];
  };

  const groupMenuItemsBySection = (items: MenuItem[]) => {
    const sections = {
      main: { title: '', order: 1, showTitle: false },
      management: { title: 'Management', order: 2, showTitle: true },
      academic: { title: 'Academic', order: 3, showTitle: true },
      finance: { title: 'Finance', order: 4, showTitle: true },
      communication: { title: 'Communication', order: 5, showTitle: true }
    };

    const grouped: Record<string, MenuItem[]> = {};
    items.forEach(item => {
      const section = item.section;
      if (!grouped[section]) {
        grouped[section] = [];
      }
      grouped[section].push(item);
    });

    return { grouped, sections };
  };

  const { grouped, sections } = groupMenuItemsBySection(getMenuItems());

  const sortedSections = Object.keys(grouped).sort((a, b) =>
    (sections[a as keyof typeof sections]?.order || 999) - (sections[b as keyof typeof sections]?.order || 999)
  );

  const colors = {
    primary: '#002B5B',
    accent: '#FFFFFF',  // Changed from Yellow to White for professional look
    activeBg: '#2D54A8',
    white: '#FFFFFF',
    textSecondary: 'rgba(255, 255, 255, 0.6)',
    border: 'rgba(255, 255, 255, 0.05)'
  };

  return (
    <>
      <style>
        {`
          .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.2);
          }
        `}
      </style>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={toggleSidebar}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:relative top-0 left-0 z-50 h-screen transition-all duration-300 ease-in-out flex flex-col ${isCollapsed ? 'w-14' : 'w-60'
          } ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
        style={{ backgroundColor: colors.primary }}
      >
        {/* Logo Section */}
        <div className={`h-16 flex-shrink-0 flex items-center justify-between border-b border-white/5 ${isCollapsed ? 'px-2' : 'px-5'}`}>
          {!isCollapsed && (
            <div className="flex items-center space-x-2.5">
             
              <span className="font-bold text-white text-lg tracking-tight">SmartSchool ERP
              </span>
            </div>
          )}
          {isCollapsed && (
            <div className="w-full flex justify-center">
              <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center shadow-sm">
                <School className="text-[#002B5B] w-5 h-5" />
              </div>
            </div>
          )}
          <button
            onClick={toggleCollapse}
            className="text-white/40 hover:text-white p-1 rounded-lg transition-colors hidden lg:block hover:bg-white/5"
          >
            {isCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 overflow-y-auto custom-scrollbar pt-3 pb-4 px-2 space-y-0.5">
          {sortedSections.map((sectionKey) => {
            const sectionConfig = sections[sectionKey as keyof typeof sections];
            return (
              <div key={sectionKey}>
                {!isCollapsed && sectionConfig?.showTitle && (
                  <h3 className="text-[10px] font-bold text-white/30 uppercase tracking-[0.15em] px-4 mt-4 mb-1.5">
                    {sectionConfig.title}
                  </h3>
                )}
                <ul className="space-y-0.5">
                  {grouped[sectionKey].map((item) => (
                    <li key={item.label}>
                      {item.subItems ? (
                        <div>
                          <button
                            onClick={() => toggleDropdown(item.label)}
                            className={`w-full flex items-center justify-between rounded-lg px-2 py-2 transition-all duration-200 ${openDropdown === item.label
                                ? 'bg-white/5 text-white'
                                : 'text-white/70 hover:bg-white/5 hover:text-white'
                              } ${isCollapsed ? 'justify-center' : ''}`}
                          >
                            <div className="flex items-center space-x-2.5">
                              <item.icon size={18} className={openDropdown === item.label ? 'text-white' : 'text-white/60'} />
                              {!isCollapsed && <span className="text-[13px] font-medium">{item.label}</span>}
                            </div>
                            {!isCollapsed && (
                              <ChevronDown
                                size={12}
                                className={`transition-transform duration-200 text-white/30 ${openDropdown === item.label ? 'rotate-180 text-white/70' : ''}`}
                              />
                            )}
                          </button>
                          {openDropdown === item.label && !isCollapsed && (
                            <ul className="mt-0.5 space-y-0.5">
                              {item.subItems.map(sub => (
                                <li key={sub.path}>
                                  <NavLink
                                    to={sub.path}
                                    className={({ isActive }) =>
                                      `flex items-center py-2 pl-10 pr-4 text-[12px] rounded-lg transition-all duration-200 ${isActive
                                        ? 'text-white font-semibold bg-white/10'
                                        : 'text-white/50 hover:text-white hover:bg-white/5'
                                      }`
                                    }
                                  >
                                    {sub.label}
                                  </NavLink>
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      ) : (
                        <NavLink
                          to={item.path!}
                          className={({ isActive }) =>
                            `flex items-center rounded-lg px-2 py-2 transition-all duration-200 ${isActive
                              ? 'bg-[#2D54A8] text-white shadow-sm font-semibold'
                              : 'text-white/70 hover:bg-white/5 hover:text-white'
                            } ${isCollapsed ? 'justify-center' : ''}`
                          }
                          onClick={() => window.innerWidth < 1024 && toggleSidebar()}
                        >
                          {({ isActive }) => (
                            <>
                              <item.icon size={18} className={`flex-shrink-0 ${isActive ? 'text-white' : 'text-white/60'}`} />
                              {!isCollapsed && <span className="ml-2.5 text-[13px] font-medium">{item.label}</span>}
                            </>
                          )}
                        </NavLink>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </nav>

        {/* Profile Section */}
        <div className="p-3 border-t border-white/10">
          <NavLink
            to={`/${user?.role}/profile`}
            className={({ isActive }) =>
              `flex items-center rounded-xl px-2 py-2 transition-all duration-200 ${isActive ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'
              } ${isCollapsed ? 'justify-center' : ''}`
            }
          >
            {({ isActive }) => (
              <>
                <User size={18} className={isActive ? 'text-white' : 'text-white/60'} />
                {!isCollapsed && <span className="ml-2.5 text-sm font-medium">My Profile</span>}
              </>
            )}
          </NavLink>
          <button
            onClick={logout}
            className={`w-full flex items-center rounded-xl px-2 py-2 text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all duration-200 mt-1 ${isCollapsed ? 'justify-center' : ''}`}
          >
            <LogOut size={18} />
            {!isCollapsed && <span className="ml-2.5 text-sm font-medium">Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;