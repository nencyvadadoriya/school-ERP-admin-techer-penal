import React, { useState, useEffect } from 'react';
import AutoNotificationManager from '../../components/AutoNotificationManager';
import {
  Users,
  GraduationCap,
  School,
  Wallet,
  CalendarCheck2,
  FileText,
  BarChart3,
  Trophy,
  Users2,
  BookOpen,
  Percent,
  Bell,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  Download,
  MoreHorizontal,
  CheckCircle2,
  Clock,
  AlertTriangle,
  UserPlus,
  Moon,
  Sun,
  LayoutDashboard,
  Calendar,
  ShieldCheck,
  Search,
  Home,
  PieChart,
  User
} from 'lucide-react';
import { toast } from 'react-toastify';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart as RePieChart, Pie, Cell, LineChart, Line,
  AreaChart, Area, ComposedChart
} from 'recharts';
import { dashboardAPI, attendanceAPI } from '../../services/api';
import Spinner from '../../components/Spinner';

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalTeachers: 0,
    totalClasses: 0,
    attendancePercentage: 0,
    pendingLeaves: 0,
    feesCollected: 0,
    pendingTeacherLeaves: 0,
    pendingStudentLeaves: 0,
    feesPending: 0,
    charts: {
      weeklyAttendance: [],
      genderDistribution: [],
      teacherWorkload: []
    }
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [checkingAttendance, setCheckingAttendance] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [activeMobileTab, setActiveMobileTab] = useState<string>('home');

  const theme = {
    primary: '#002B5B',
    secondary: '#2D54A8',
    accent: '#FFC107',
    background: '#F0F2F5',
    white: '#FFFFFF',
    textPrimary: '#1F2937',
    textSecondary: '#6B7280'
  };

  const monthlyFeesData = [
    { month: 'Jan', collected: 125000, pending: 45000, target: 170000 },
    { month: 'Feb', collected: 142000, pending: 38000, target: 180000 },
    { month: 'Mar', collected: 158000, pending: 25000, target: 183000 },
    { month: 'Apr', collected: 135000, pending: 42000, target: 177000 },
    { month: 'May', collected: 148000, pending: 35000, target: 183000 },
    { month: 'Jun', collected: 165000, pending: 28000, target: 193000 },
  ];

  const classPerformanceData = [
    { class: '10A', avgScore: 78, students: 42, rank: 2, improvement: +5 },
    { class: '10B', avgScore: 74, students: 40, rank: 3, improvement: +3 },
    { class: '9A', avgScore: 82, students: 45, rank: 1, improvement: +7 },
    { class: '9B', avgScore: 71, students: 43, rank: 4, improvement: +2 },
    { class: '8A', avgScore: 79, students: 44, rank: 2, improvement: +4 },
    { class: '8B', avgScore: 76, students: 41, rank: 3, improvement: +6 },
  ];

  const resultDistribution = [
    { range: '90-100%', students: 45, color: '#10b981', percentage: 18 },
    { range: '75-89%', students: 78, color: '#3b82f6', percentage: 31 },
    { range: '60-74%', students: 62, color: '#f59e0b', percentage: 25 },
    { range: '40-59%', students: 35, color: '#f97316', percentage: 14 },
    { range: 'Below 40%', students: 12, color: '#ef4444', percentage: 12 },
  ];

  const monthlyAttendance = [
    { month: 'Jan', percentage: 92, target: 90, previousYear: 88 },
    { month: 'Feb', percentage: 89, target: 90, previousYear: 87 },
    { month: 'Mar', percentage: 94, target: 90, previousYear: 89 },
    { month: 'Apr', percentage: 91, target: 90, previousYear: 86 },
    { month: 'May', percentage: 87, target: 90, previousYear: 85 },
    { month: 'Jun', percentage: 93, target: 90, previousYear: 88 },
  ];

  const weeklyAttendanceData = [
    { day: 'Mon', present: 420, absent: 45, total: 465 },
    { day: 'Tue', present: 435, absent: 30, total: 465 },
    { day: 'Wed', present: 445, absent: 20, total: 465 },
    { day: 'Thu', present: 430, absent: 35, total: 465 },
    { day: 'Fri', present: 425, absent: 40, total: 465 },
    { day: 'Sat', present: 410, absent: 55, total: 465 },
  ];

  const genderDistributionData = [
    { name: 'Boys', value: 245, color: '#002B5B' },
    { name: 'Girls', value: 220, color: '#2D54A8' },
  ];

  useEffect(() => {
    fetchDashboard();
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const checkMobile = () => {
    setIsMobile(window.innerWidth < 768);
  };

  const fetchDashboard = async () => {
    try {
      const res = await dashboardAPI.admin();
      setStats({
        ...res.data.data,
        pendingTeacherLeaves: res.data.data?.pendingTeacherLeaves ?? 0,
        pendingStudentLeaves: res.data.data?.pendingStudentLeaves ?? 0,
      });
    } catch (e) {
      console.error(e);
    } finally { setLoading(false); }
  };

  const handleCheckMissingAttendance = async () => {
    setCheckingAttendance(true);
    try {
      const res = await attendanceAPI.checkMissingAttendance();
      if (res.data.success) {
        toast.success(res.data.message + ` Reminders sent to ${res.data.missing_count} teachers.`);
      }
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to check attendance');
    } finally {
      setCheckingAttendance(false);
    }
  };

  if (loading) return <Spinner />;

  if (isMobile) {
    const renderMobileContent = () => {
      switch (activeMobileTab) {
        case 'stats':
          return (
            <div className="p-2 space-y-4 pt-2">
              <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border rounded-xl shadow-sm overflow-hidden`}>
                <h3 className={`text-sm font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} px-4 py-3 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>Attendance Trends</h3>
                <div style={{ height: '220px', width: '100%' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={monthlyAttendance} margin={{ top: 15, right: 25, left: -20, bottom: 5 }}>
                      <defs>
                        <linearGradient id="colorPercentageMobile" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={theme.secondary} stopOpacity={0.2} />
                          <stop offset="95%" stopColor={theme.secondary} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                      <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} />
                      <Tooltip cursor={{ fill: darkMode ? '#374151' : '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '12px', backgroundColor: darkMode ? '#1F2937' : '#FFFFFF', color: darkMode ? '#FFFFFF' : '#000000' }} />
                      <Area type="monotone" dataKey="percentage" stroke={theme.secondary} strokeWidth={2} fillOpacity={1} fill="url(#colorPercentageMobile)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border rounded-xl shadow-sm overflow-hidden`}>
                <h3 className={`text-sm font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} px-4 py-3 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>Weekly Attendance</h3>
                <div style={{ height: '220px', width: '100%' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyAttendanceData} margin={{ top: 15, right: 25, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                      <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} />
                      <Tooltip cursor={{ fill: darkMode ? '#374151' : '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '12px', backgroundColor: darkMode ? '#1F2937' : '#FFFFFF', color: darkMode ? '#FFFFFF' : '#000000' }} />
                      <Bar dataKey="present" fill={theme.primary} radius={[2, 2, 0, 0]} barSize={15} />
                      <Bar dataKey="absent" fill="#EF4444" radius={[2, 2, 0, 0]} barSize={15} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border rounded-xl shadow-sm overflow-hidden`}>
                <h3 className={`text-sm font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} px-4 py-3 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>Fees Collection</h3>
                <div style={{ height: '220px', width: '100%' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyFeesData} margin={{ top: 15, right: 25, left: -15, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                      <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 10 }} tickFormatter={(v) => `${(v/1000)}k`} />
                      <Tooltip cursor={{ fill: darkMode ? '#374151' : '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', fontSize: '12px', backgroundColor: darkMode ? '#1F2937' : '#FFFFFF', color: darkMode ? '#FFFFFF' : '#000000' }} />
                      <Bar dataKey="collected" fill={theme.primary} radius={[2, 2, 0, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border rounded-xl shadow-sm p-4`}>
                <h3 className={`text-sm font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-4`}>Gender Distribution</h3>
                <div style={{ height: '180px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie data={genderDistributionData} innerRadius={55} outerRadius={80} paddingAngle={8} dataKey="value">
                        {genderDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-8 mt-4">
                  {genderDistributionData.map((d, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                      <span className="text-xs font-bold text-gray-500">{d.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        case 'alerts':
          return (
            <div className="p-2 space-y-4">
              <AutoNotificationManager darkMode={darkMode} />
              
              <div className={`p-4 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
                <h3 className={`text-sm font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-4 flex items-center gap-2`}>
                  <Clock size={16} style={{ color: theme.primary }} />
                  Pending Tasks
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: darkMode ? '#1E293B' : '#F0F9FF' }}>
                    <div className="flex items-center gap-2">
                      <AlertTriangle size={16} style={{ color: theme.primary }} />
                      <span className="text-xs font-bold" style={{ color: theme.primary }}>Teacher Leaves</span>
                    </div>
                    <span className="text-lg font-black" style={{ color: theme.primary }}>{stats.pendingTeacherLeaves ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: darkMode ? '#1E293B' : '#FFF7ED' }}>
                    <div className="flex items-center gap-2">
                      <Clock size={16} className="text-amber-600" />
                      <span className="text-xs font-bold text-amber-700">Student Leaves</span>
                    </div>
                    <span className="text-lg font-black text-amber-700">{stats.pendingStudentLeaves ?? 0}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        case 'home':
        default:
          return (
            <div className="p-2 space-y-4">
              <div className="rounded-2xl p-6 text-white"
                style={{ background: `linear-gradient(135deg, ${theme.primary}, ${theme.secondary})` }}>
                <p className="text-[10px] opacity-80 uppercase tracking-widest font-bold">Admin Panel</p>
                <h2 className="text-xl font-extrabold mt-1">SmartSchool ERP</h2>
                <div className="flex items-center mt-2 text-[10px] opacity-70">
                  <Calendar size={12} className="mr-1" />
                  <span>Saturday, 18 April 2026</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  { Icon: GraduationCap, lbl: 'Total Students', val: stats.totalStudents || 465, color: theme.secondary, bg: 'bg-blue-50' },
                  { Icon: Users, lbl: 'Total Teachers', val: stats.totalTeachers || 48, color: '#10B981', bg: 'bg-emerald-50' },
                  { Icon: Percent, lbl: 'Attendance', val: `${stats.attendancePercentage || 92}%`, color: '#8B5CF6', bg: 'bg-violet-50' },
                  { Icon: Wallet, lbl: 'Fees Collected', val: `₹${((stats.feesCollected || 873000) / 100000).toFixed(1)}L`, color: '#F59E0B', bg: 'bg-amber-50' },
                ].map((s, i) => (
                  <div key={i} className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border p-3 rounded-xl shadow-sm flex flex-col items-center text-center`}>
                    <div className={`w-8 h-8 rounded-lg ${s.bg} ${darkMode ? 'bg-opacity-10' : ''} flex items-center justify-center mb-1.5`}>
                      <s.Icon size={15} style={{ color: s.color }} />
                    </div>
                    <p className="text-[5px] text-gray-400 font-bold  leading-tight tracking-wider">{s.lbl}</p>
                    <p className={`text-sm font-black ${darkMode ? 'text-white' : 'text-gray-900'} mt-0.5`}>{s.val}</p>
                  </div>
                ))}
              </div>

              {/* Added Pending Tasks to Home Tab */}
              <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border rounded-2xl shadow-sm p-3`}>
                <h3 className={`text-xs font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-3 flex items-center gap-2`}>
                  <Clock size={14} style={{ color: theme.primary }} />
                  Pending Tasks
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2.5 rounded-xl" style={{ backgroundColor: darkMode ? '#1E293B' : '#F0F9FF' }}>
                    <div className="flex items-center gap-2">
                      <AlertTriangle size={14} style={{ color: theme.primary }} />
                      <span className="text-[10px] font-bold" style={{ color: theme.primary }}>Teacher Leaves</span>
                    </div>
                    <span className="text-base font-black" style={{ color: theme.primary }}>{stats.pendingTeacherLeaves ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl" style={{ backgroundColor: darkMode ? '#1E293B' : '#FFF7ED' }}>
                    <div className="flex items-center gap-2">
                      <Clock size={14} className="text-amber-600" />
                      <span className="text-[10px] font-bold text-amber-700">Student Leaves</span>
                    </div>
                    <span className="text-base font-black text-amber-700">{stats.pendingStudentLeaves ?? 0}</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl" style={{ backgroundColor: darkMode ? '#1E293B' : '#ECFDF5' }}>
                    <div className="flex items-center gap-2">
                      <Wallet size={14} className="text-emerald-600" />
                      <span className="text-[10px] font-bold text-emerald-700">Pending Fees</span>
                    </div>
                    <span className="text-base font-black text-emerald-700">₹{((stats.feesPending ?? 213000) / 1000).toFixed(0)}K</span>
                  </div>
                </div>
              </div>
            </div>
          );
      }
    };

    return (
      <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-[#F0F2F5]'}`}>
        <div className="pb-20 overflow-y-auto p-0">
          {renderMobileContent()}
        </div>
        <div className={`fixed bottom-0 left-0 right-0 z-50 ${darkMode ? 'bg-gray-900/95 border-gray-800' : 'bg-white/95 border-gray-200'} border-t backdrop-blur-xl`}>
          <div className="flex items-center justify-around py-2 px-2">
            {[
              { id: 'home', Icon: Home, label: 'Home' },
              { id: 'stats', Icon: PieChart, label: 'Stats' },
              { id: 'alerts', Icon: Bell, label: 'Alerts' },
            ].map(({ id, Icon, label }) => (
              <button key={id} onClick={() => setActiveMobileTab(id)} className="flex flex-col items-center flex-1 py-1">
                <Icon size={20} className={activeMobileTab === id ? 'text-[#002B5B]' : 'text-gray-400'} />
                <span className={`text-[10px] mt-1 ${activeMobileTab === id ? 'text-[#002B5B] font-bold' : 'text-gray-500'}`}>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-all duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-[#F0F2F5]'}`}>
      {/* Header - Removed sticky, now normal block that scrolls away */}
      <div className={`${darkMode ? 'bg-gray-900/80 border-gray-800' : 'bg-white border-gray-200'} border-b px-8 py-4`}>
        <div className="flex items-center justify-between max-w-[1600px] mx-auto">
          <div>
            <h1 className={`${darkMode ? 'text-white' : 'text-gray-900'} tracking-tight`}
              style={{
                fontSize: '24px',
                fontWeight: '800',
                color: darkMode ? '#FFFFFF' : '#002B5B'
              }}>
              SmartSchool ERP
            </h1>
            <div className="flex items-center mt-1 space-x-4">
              <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}
                style={{
                  fontSize: '11px',
                  color: darkMode ? '#9CA3AF' : '#6B7280'
                }}>
                Saturday, 18 April 2026
              </span>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input type="text" placeholder="Search..." className="pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#002B5B]/10 transition-all w-64" />
            </div>
            <button onClick={() => setDarkMode(!darkMode)}
              className={`p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-yellow-400' : 'bg-gray-100 text-gray-600'}`}>
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button onClick={handleCheckMissingAttendance} disabled={checkingAttendance}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-sm font-bold shadow-lg shadow-[#002B5B]/20 transition-all active:scale-95 hover:brightness-110"
              style={{ background: theme.primary }}>
              <Bell size={18} className={checkingAttendance ? 'animate-spin' : ''} />
              {checkingAttendance ? 'Checking...' : 'Check Attendance'}
            </button>
          </div>
        </div>
      </div>

      <div className="p-8 max-w-[1600px] mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { Icon: GraduationCap, label: 'Total Students', value: stats.totalStudents || 465, color: theme.secondary, bg: 'bg-blue-50' },
            { Icon: Users, label: 'Total Teachers', value: stats.totalTeachers || 48, color: '#10B981', bg: 'bg-emerald-50' },
            { Icon: BarChart3, label: 'Attendance Rate', value: `${stats.attendancePercentage || 92}%`, color: '#8B5CF6', bg: 'bg-violet-50' },
            { Icon: Wallet, label: 'Fees Collected', value: `₹${((stats.feesCollected || 873000) / 100000).toFixed(1)}L`, color: '#F59E0B', bg: 'bg-amber-50' }
          ].map((stat, i) => (
            <div key={i} className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm hover:shadow-md transition-all group relative overflow-hidden`}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className={`text-sm font-semibold mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{stat.label}</p>
                  <h3 className={`text-2xl font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stat.value}</h3>
                </div>
                <div className={`p-2.5 rounded-lg ${stat.bg} ${darkMode ? 'bg-opacity-10' : ''}`}>
                  <stat.Icon size={18} style={{ color: stat.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className={`p-8 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-xl font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-8`}>Attendance Trends</h3>
              <div style={{ height: '350px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyAttendance}>
                    <defs>
                      <linearGradient id="colorPercentage" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={theme.secondary} stopOpacity={0.2} />
                        <stop offset="95%" stopColor={theme.secondary} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 600 }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 600 }} dx={-10} />
                    <Tooltip cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Area type="monotone" dataKey="percentage" stroke={theme.secondary} strokeWidth={3} fillOpacity={1} fill="url(#colorPercentage)" name="Current Year" />
                    <Line type="monotone" dataKey="target" stroke="#F59E0B" strokeDasharray="5 5" name="Target" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className={`p-8 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-xl font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-8`}>Weekly Attendance Overview</h3>
              <div style={{ height: '350px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyAttendanceData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                    <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 600 }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 600 }} dx={-10} />
                    <Tooltip cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ paddingBottom: '20px' }} />
                    <Bar dataKey="present" fill={theme.primary} name="Present" radius={[6, 6, 0, 0]} barSize={20} />
                    <Bar dataKey="absent" fill="#EF4444" name="Absent" radius={[6, 6, 0, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Monthly Fees Collection - Bar Chart Version with Theme Colors */}
            <div className={`p-8 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-xl font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-8`}>Monthly Fees Collection</h3>
              <div style={{ height: '320px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyFeesData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#374151' : '#F1F5F9'} />
                    <XAxis
                      dataKey="month"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: darkMode ? '#9CA3AF' : '#6B7280', fontSize: 12, fontWeight: 500 }}
                      dy={10}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: darkMode ? '#9CA3AF' : '#6B7280', fontSize: 12, fontWeight: 500 }}
                      dx={-10}
                      tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: darkMode ? '#1F2937' : '#FFFFFF',
                        border: 'none',
                        borderRadius: '12px',
                        boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'
                      }}
                      formatter={(value: number) => [`₹${(value / 1000).toFixed(1)}K`, '']}
                    />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      iconType="circle"
                      wrapperStyle={{ paddingBottom: '20px' }}
                    />
                    <Bar
                      dataKey="collected"
                      name="Collected"
                      fill={theme.primary}
                      radius={[8, 8, 0, 0]}
                      barSize={35}
                    />
                    <Bar
                      dataKey="pending"
                      name="Pending"
                      fill={theme.secondary}
                      radius={[8, 8, 0, 0]}
                      barSize={35}
                    />
                    <Line
                      type="monotone"
                      dataKey="target"
                      stroke={theme.accent}
                      name="Target"
                      strokeWidth={2.5}
                      strokeDasharray="6 4"
                      dot={false}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {/* Pending Tasks Card - Updated with Theme Colors */}
            <div className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-lg font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-6 flex items-center gap-2`}>
                <Clock size={20} style={{ color: theme.primary }} />
                Pending Tasks
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl transition-all hover:shadow-md"
                  style={{ backgroundColor: darkMode ? '#1E293B' : '#F0F9FF', border: `1px solid ${darkMode ? '#334155' : theme.primary + '20'}` }}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg" style={{ backgroundColor: darkMode ? theme.primary + '40' : theme.primary + '10' }}>
                      <AlertTriangle size={18} style={{ color: theme.primary }} />
                    </div>
                    <span className="text-sm font-bold" style={{ color: theme.primary }}>Teacher Leaves</span>
                  </div>
                  <span className="text-xl font-black" style={{ color: theme.primary }}>{stats.pendingTeacherLeaves ?? 0}</span>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl transition-all hover:shadow-md"
                  style={{ backgroundColor: darkMode ? '#1E293B' : '#FFF7ED', border: `1px solid ${darkMode ? '#334155' : '#F59E0B20'}` }}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg" style={{ backgroundColor: darkMode ? '#F59E0B40' : '#FEF3C7' }}>
                      <Clock size={18} className="text-amber-600" />
                    </div>
                    <span className="text-sm font-bold text-amber-700 dark:text-amber-400">Student Leaves</span>
                  </div>
                  <span className="text-xl font-black text-amber-700 dark:text-amber-400">{stats.pendingStudentLeaves ?? 0}</span>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl transition-all hover:shadow-md"
                  style={{ backgroundColor: darkMode ? '#1E293B' : '#ECFDF5', border: `1px solid ${darkMode ? '#334155' : '#10B98120'}` }}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg" style={{ backgroundColor: darkMode ? '#10B98140' : '#D1FAE5' }}>
                      <Wallet size={18} className="text-emerald-600" />
                    </div>
                    <span className="text-sm font-bold text-emerald-700 dark:text-emerald-400">Pending Fees</span>
                  </div>
                  <span className="text-xl font-black text-emerald-700 dark:text-emerald-400">₹{((stats.feesPending ?? 213000) / 1000).toFixed(0)}K</span>
                </div>
              </div>
            </div>

            <div className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-lg font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-6`}>Gender Distribution</h3>
              <div style={{ height: '240px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie data={genderDistributionData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                      {genderDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RePieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-4">
                {genderDistributionData.map((d, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                    <span className={`text-sm font-bold ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{d.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-transparent'} border shadow-sm`}>
              <h3 className={`text-lg font-extrabold ${darkMode ? 'text-white' : 'text-gray-900'} mb-6`}>Performance Rankings</h3>
              <div className="space-y-4">
                {classPerformanceData.sort((a, b) => b.avgScore - a.avgScore).slice(0, 4).map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-700/50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white dark:bg-gray-600 flex items-center justify-center font-bold text-sm shadow-sm" style={{ color: theme.primary }}>
                        {i + 1}
                      </div>
                      <span className={`font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>{item.class}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold" style={{ color: theme.primary }}>{item.avgScore}%</span>
                      {item.improvement > 0 ? <ArrowUpRight size={14} className="text-emerald-500" /> : <ArrowDownRight size={14} className="text-rose-500" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <AutoNotificationManager darkMode={darkMode} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;