import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  CalendarCheck2,
  Wallet,
  GraduationCap,
  BookOpen,
  ClipboardList,
  Grid3X3
} from 'lucide-react';

interface MobileBottomNavProps {
  onMenuOpen: () => void;
}

const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ onMenuOpen }) => {
  const { user } = useAuth();
  const location = useLocation();

  const adminTabs = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Home' },
    { path: '/admin/students', icon: Users, label: 'Students' },
    { path: '/admin/attendance', icon: CalendarCheck2, label: 'Attendance' },
    { path: '/admin/fees', icon: Wallet, label: 'Fees' },
    { label: 'Menu', icon: Grid3X3, isMenu: true },
  ];

  const teacherTabs = [
    { path: '/teacher/dashboard', icon: LayoutDashboard, label: 'Home' },
    { path: '/teacher/attendance', icon: CalendarCheck2, label: 'Attendance' },
    { path: '/teacher/homework', icon: BookOpen, label: 'Homework' },
    { path: '/teacher/exams', icon: ClipboardList, label: 'Exams' },
    { label: 'Menu', icon: Grid3X3, isMenu: true },
  ];

  const studentTabs = [
    { path: '/student/dashboard', icon: LayoutDashboard, label: 'Home' },
    { path: '/student/timetable', icon: CalendarCheck2, label: 'Timetable' },
    { path: '/student/leave', icon: ClipboardList, label: 'Leave' },
    { path: '/student/profile', icon: GraduationCap, label: 'Profile' },
    { label: 'Menu', icon: Grid3X3, isMenu: true },
  ];

  const getTabs = () => {
    if (user?.role === 'admin' || user?.role === 'sub_admin') return adminTabs;
    if (user?.role === 'teacher') return teacherTabs;
    if (user?.role === 'student') return studentTabs;
    return adminTabs;
  };

  const tabs = getTabs();

  return (
    <>
      <style>{`
        .bottom-nav-bar {
          background: #ffffff;
          border-top: 1px solid #e5e7eb;
          box-shadow: 0 -4px 20px rgba(0, 43, 91, 0.08);
        }
        .bottom-tab-active {
          color: #002B5B;
        }
        .bottom-tab-active .tab-icon-bg {
          background: linear-gradient(135deg, #002B5B 0%, #2D54A8 100%);
          transform: translateY(-4px) scale(1.05);
          box-shadow: 0 4px 12px rgba(0, 43, 91, 0.35);
        }
        .bottom-tab-active .tab-icon-bg svg {
          color: white !important;
        }
        .bottom-tab-active .tab-label {
          color: #002B5B;
          font-weight: 700;
        }
        .bottom-tab-inactive .tab-icon-bg {
          background: transparent;
          transform: translateY(0) scale(1);
        }
        .bottom-tab-inactive .tab-label {
          color: #9ca3af;
          font-weight: 500;
        }
        .menu-tab-btn .tab-icon-bg {
          background: linear-gradient(135deg, #002B5B 0%, #2D54A8 100%);
          transform: translateY(-4px) scale(1.05);
          box-shadow: 0 4px 12px rgba(0, 43, 91, 0.35);
        }
        .menu-tab-btn .tab-icon-bg svg {
          color: white !important;
        }
        .menu-tab-btn .tab-label {
          color: #002B5B;
          font-weight: 700;
        }
        .tab-icon-bg {
          width: 44px;
          height: 44px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .tab-label {
          font-size: 10px;
          margin-top: 2px;
          transition: color 0.2s;
          letter-spacing: 0.02em;
        }
        .bottom-tab {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 6px 0 4px;
          flex: 1;
          cursor: pointer;
          position: relative;
          -webkit-tap-highlight-color: transparent;
        }
        .bottom-tab:active .tab-icon-bg {
          transform: translateY(-2px) scale(0.98);
        }
      `}</style>
      <nav className="bottom-nav-bar fixed bottom-0 left-0 right-0 z-40 flex safe-bottom" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
        {tabs.map((tab: any, idx) => {
          const Icon = tab.icon;
          if (tab.isMenu) {
            return (
              <button
                key="menu"
                onClick={onMenuOpen}
                className="bottom-tab menu-tab-btn"
              >
                <div className="tab-icon-bg">
                  <Icon size={20} />
                </div>
                <span className="tab-label">{tab.label}</span>
              </button>
            );
          }
          const isActive = location.pathname === tab.path;
          return (
            <NavLink
              key={tab.path}
              to={tab.path}
              className={`bottom-tab ${isActive ? 'bottom-tab-active' : 'bottom-tab-inactive'}`}
            >
              <div className="tab-icon-bg">
                <Icon size={20} className={isActive ? 'text-white' : 'text-gray-400'} />
              </div>
              <span className="tab-label">{tab.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </>
  );
};

export default MobileBottomNav;
